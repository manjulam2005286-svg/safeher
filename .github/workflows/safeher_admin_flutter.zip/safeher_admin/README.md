# SafeHer – Admin App (Flutter)

Response-desk app for admins. Connects to the existing SafeHer Node.js server.

## Features
- Admin login with server address field (default demo admin: admin@safeher.com / admin123)
- **Real-time alerts** through the server's SSE stream (`/api/admin/stream`), auto-reconnect, Live/Offline indicator
- **New SOS popup** with user details, location, primary contact – Mark Responded / View details / Dismiss
- **Siren with ON/OFF switch** (speaker icon in the top bar; choice is saved)
- **Missed alerts**: pending alerts raised while the admin was logged out pop up at the next login (NEW badge)
- Dashboard stats: total users, active alerts, resolved, contacts; status filter chips
- **Alert detail**: live map that follows the user, movement trail, start point, accuracy,
  "approximate" / "set by user" labels, call user / contacts, open in Google Maps, update status

## Requirements
- Flutter 3.22 or newer
- Android phone / emulator, or run on desktop/web for testing
- SafeHer server running on a laptop on the same network

## Setup (one time)
```
cd safeher_admin
setup.bat          (Windows)
./setup.sh         (Linux / macOS)
```

## Run
1. Start the server on the laptop: `npm start`
2. `flutter run`
3. Login screen: enter admin email, password and server address `http://<laptop-ip>:5050`

## Build APK
```
flutter build apk --release
```

## Notes
- Alerts arrive while the app is open (foreground). Push notifications when the app is closed
  would need Firebase Cloud Messaging (future enhancement).
- If `flutter pub get` reports a version conflict on a newer Flutter, run `flutter pub upgrade --major-versions`.
