import 'package:flutter/material.dart';
import '../theme.dart';

void toast(BuildContext context, String msg, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg), backgroundColor: error ? AppColors.red : AppColors.ink, behavior: SnackBarBehavior.floating));
}

Future<bool> confirmDialog(BuildContext context,
    {required String title, String body = '', String ok = 'Confirm', String cancel = 'Cancel', bool danger = false}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(title),
      content: body.isEmpty ? null : Text(body),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: Text(cancel)),
        FilledButton(
            style: danger ? FilledButton.styleFrom(backgroundColor: AppColors.red) : null,
            onPressed: () => Navigator.pop(c, true),
            child: Text(ok)),
      ],
    ),
  );
  return r ?? false;
}

/// Status label that uses text + colour (never colour alone).
class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip(this.status, {super.key});
  @override
  Widget build(BuildContext context) {
    final (Color bg, Color fg) = switch (status) {
      'Pending' || 'NEW' => (const Color(0xFFFFE4EA), const Color(0xFF9F1239)),
      'Responded' => (const Color(0xFFFFF4D6), const Color(0xFF92400E)),
      'Resolved' => (const Color(0xFFDCFCE7), const Color(0xFF166534)),
      _ => (const Color(0xFFECEEF3), const Color(0xFF5B6070)),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Text(status, style: TextStyle(color: fg, fontWeight: FontWeight.w700, fontSize: 12)),
    );
  }
}

class SectionCard extends StatelessWidget {
  final String? title;
  final Widget? trailing;
  final Widget child;
  final EdgeInsets padding;
  final Color? color;
  final Color? borderColor;
  const SectionCard({super.key, this.title, this.trailing, required this.child, this.padding = const EdgeInsets.all(16), this.color, this.borderColor});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
          color: color ?? Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: borderColor ?? AppColors.line, width: borderColor == null ? 1 : 2)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (title != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Row(children: [
              Expanded(child: Text(title!, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
              if (trailing != null) trailing!,
            ]),
          ),
        child,
      ]),
    );
  }
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title, text;
  final Widget? action;
  const EmptyState({super.key, required this.icon, required this.title, required this.text, this.action});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 12),
      child: Column(children: [
        CircleAvatar(radius: 26, backgroundColor: AppColors.soft, child: Icon(icon, color: AppColors.primary)),
        const SizedBox(height: 10),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(text, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.grey)),
        if (action != null) ...[const SizedBox(height: 12), action!],
      ]),
    );
  }
}

class WarnBox extends StatelessWidget {
  final String text;
  final bool good;
  const WarnBox(this.text, {super.key, this.good = false});
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: good ? const Color(0xFFDCFCE7) : const Color(0xFFFFF4D6), borderRadius: BorderRadius.circular(10)),
        child: Text(text,
            style: TextStyle(color: good ? const Color(0xFF166534) : const Color(0xFF92400E), fontWeight: FontWeight.w600, fontSize: 13)),
      );
}

String fmtDateTime(String iso) {
  final d = DateTime.tryParse(iso)?.toLocal();
  if (d == null) return iso;
  String two(int n) => n.toString().padLeft(2, '0');
  return '${two(d.day)}/${two(d.month)}/${d.year}  ${two(d.hour)}:${two(d.minute)}';
}

String agoText(String? iso) {
  final d = iso == null ? null : DateTime.tryParse(iso);
  if (d == null) return '';
  final s = DateTime.now().difference(d.toLocal()).inSeconds;
  if (s < 60) return '${s < 0 ? 0 : s}s ago';
  if (s < 3600) return '${s ~/ 60}m ago';
  return fmtDateTime(iso!);
}
