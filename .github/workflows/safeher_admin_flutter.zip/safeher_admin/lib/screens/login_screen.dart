import 'package:flutter/material.dart';
import '../api.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'dashboard_screen.dart';

class LoginScreen extends StatefulWidget {
  final String? message;
  const LoginScreen({super.key, this.message});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController(), _pw = TextEditingController();
  late final _server = TextEditingController(text: Api.I.baseUrl);
  bool _busy = false;
  String? _err;

  @override
  void initState() {
    super.initState();
    _err = widget.message;
  }

  Future<void> _submit() async {
    setState(() {
      _busy = true;
      _err = null;
    });
    try {
      await Api.I.setServer(_server.text);
      await Api.I.login(_email.text.trim(), _pw.text);
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const DashboardScreen()), (_) => false);
    } on ApiException catch (e) {
      setState(() => _err = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  const Icon(Icons.admin_panel_settings, size: 64, color: AppColors.primary),
                  const Text('SafeHer Admin', textAlign: TextAlign.center, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
                  const Text('Emergency response dashboard', textAlign: TextAlign.center, style: TextStyle(color: AppColors.grey)),
                  const SizedBox(height: 24),
                  TextField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Admin email', prefixIcon: Icon(Icons.mail_outline))),
                  const SizedBox(height: 12),
                  TextField(controller: _pw, obscureText: true, onSubmitted: (_) => _submit(),
                      decoration: const InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock_outline))),
                  const SizedBox(height: 12),
                  TextField(controller: _server, keyboardType: TextInputType.url,
                      decoration: const InputDecoration(labelText: 'Server address', hintText: 'http://192.168.1.10:5050', prefixIcon: Icon(Icons.dns_outlined))),
                  if (_err != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_err!, style: const TextStyle(color: AppColors.red))),
                  const SizedBox(height: 18),
                  FilledButton(onPressed: _busy ? null : _submit, child: Text(_busy ? 'Logging in…' : 'Log in')),
                  const SizedBox(height: 10),
                  const Text('Default demo admin: admin@safeher.com / admin123', textAlign: TextAlign.center, style: TextStyle(color: AppColors.grey, fontSize: 12)),
                ]),
              ),
            ),
          ),
        ),
      );
}

// Re-exported so other screens can show toasts without importing common.dart twice.
void showToast(BuildContext c, String m, {bool error = false}) => toast(c, m, error: error);
