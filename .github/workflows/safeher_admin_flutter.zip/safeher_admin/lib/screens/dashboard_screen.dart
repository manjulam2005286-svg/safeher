import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../services/sound.dart';
import '../services/sse.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'alert_detail_screen.dart';
import 'login_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with WidgetsBindingObserver {
  Map<String, dynamic> _stats = {};
  List<Map<String, dynamic>> _alerts = [];
  String _filter = 'All';
  bool _loaded = false, _connected = false, _first = true, _busy = false, _again = false, _alarmOpen = false;
  late bool _soundOn = Api.I.prefs.getBool('soundOn') ?? true;
  final Set<int> _seen = {}, _newIds = {};
  late final Set<String> _shown = Set<String>.from(jsonDecode(Api.I.prefs.getString('shown') ?? '[]') as List);
  Timer? _poll, _tick;
  late final AdminStream _stream = AdminStream(
    onEvent: (event, data) {
      if (event == 'cancel' && mounted) toast(context, '✋ ${data['user'] ?? 'User'} cancelled SOS alert #${data['id']}');
      _load();
    },
    onStatus: (c) {
      if (mounted) setState(() => _connected = c);
    },
    onUnauthorized: () => Api.I.onSessionExpired?.call(),
  );

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
    _stream.start();
    _poll = Timer.periodic(const Duration(seconds: 5), (_) => _load());
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _stream.stop();
    _poll?.cancel();
    _tick?.cancel();
    Siren.stop();
    super.dispose();
  }

  String _key(Map a) => '${a['id']}@${a['createdAt']}';

  Future<void> _load() async {
    if (_busy) {
      _again = true;
      return;
    }
    _busy = true;
    try {
      final r = await Future.wait([Api.I.dashboard(), Api.I.alerts()]);
      if (!mounted) return;
      final alerts = List<Map<String, dynamic>>.from(r[1] as List);
      // First load: pending alerts never shown to this admin (arrived while away). Later: anything new.
      final fresh = alerts
          .where((a) => a['status'] == 'Pending' && (_first ? !_shown.contains(_key(a)) : !_seen.contains((a['id'] as num).toInt())))
          .toList();
      for (final a in alerts) {
        _seen.add((a['id'] as num).toInt());
      }
      setState(() {
        _stats = r[0] as Map<String, dynamic>;
        _alerts = alerts;
        _loaded = true;
        _newIds.addAll(fresh.map((a) => (a['id'] as num).toInt()));
      });
      if (fresh.isNotEmpty) {
        _shown.addAll(fresh.map(_key));
        await Api.I.prefs.setString('shown', jsonEncode(_shown.toList().reversed.take(500).toList()));
        if (_first && fresh.length > 1 && mounted) toast(context, '🚨 ${fresh.length} pending SOS alerts arrived while you were away');
        _alarm(fresh.first);
      }
      _first = false;
    } on ApiException catch (e) {
      if (mounted && e.status != 401) setState(() => _loaded = true);
    } finally {
      _busy = false;
      if (_again) {
        _again = false;
        _load();
      }
    }
  }

  Future<void> _toggleSound() async {
    setState(() => _soundOn = !_soundOn);
    await Api.I.prefs.setBool('soundOn', _soundOn);
    if (!_soundOn) Siren.stop();
    if (mounted) toast(context, _soundOn ? '🔔 Alert sound turned ON' : '🔕 Alert sound turned OFF');
  }

  Future<void> _alarm(Map<String, dynamic> a) async {
    if (_alarmOpen || !mounted) return;
    _alarmOpen = true;
    if (_soundOn) Siren.start();
    HapticFeedback.vibrate();
    final user = Map<String, dynamic>.from(a['user'] as Map? ?? {});
    final contacts = List<Map<String, dynamic>>.from(a['contacts'] as List? ?? []);
    Map<String, dynamic>? primary;
    for (final c in contacts) {
      if (c['primary'] == true) primary = c;
    }
    primary ??= contacts.isEmpty ? null : contacts.first;
    final action = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (c) => AlertDialog(
        icon: const Icon(Icons.warning_amber_rounded, color: AppColors.red, size: 40),
        title: const Text('NEW SOS ALERT', style: TextStyle(color: AppColors.red, fontWeight: FontWeight.w800)),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${user['name'] ?? ''}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          Text('📞 ${user['phone'] ?? ''}\n✉ ${user['email'] ?? ''}'),
          const SizedBox(height: 8),
          Text('📍 ${(a['lat'] as num).toStringAsFixed(6)}, ${(a['lng'] as num).toStringAsFixed(6)}'),
          if (isApprox(a)) WarnBox('⚠ Approximate location (${accuracyText(a['accuracy'] as num)}). Sender has no precise GPS fix.'),
          Text('🕒 ${fmtDateTime(a['createdAt'] as String)}'),
          const SizedBox(height: 8),
          Text('👥 Emergency contact: ${primary == null ? 'none' : '${primary['name']} (${primary['relationship']}) ${primary['phone']}'}'),
          if (!_soundOn) const Padding(padding: EdgeInsets.only(top: 8), child: Text('🔕 Alert sound is OFF', style: TextStyle(color: AppColors.grey))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, 'dismiss'), child: const Text('Dismiss')),
          OutlinedButton(onPressed: () => Navigator.pop(c, 'view'), child: const Text('View details')),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: AppColors.red), onPressed: () => Navigator.pop(c, 'ack'), child: const Text('Mark Responded')),
        ],
      ),
    );
    await Siren.stop();
    _alarmOpen = false;
    final id = (a['id'] as num).toInt();
    if (action == 'ack') {
      try {
        await Api.I.setStatus(id, 'Responded');
        _load();
      } on ApiException catch (e) {
        if (mounted) toast(context, e.message, error: true);
      }
    } else if (action == 'view') {
      _open(id);
    }
  }

  Future<void> _open(int id) async {
    setState(() => _newIds.remove(id));
    await Navigator.push(context, MaterialPageRoute(builder: (_) => AlertDetailScreen(alertId: id)));
    _load();
  }

  Future<void> _logout() async {
    if (!await confirmDialog(context, title: 'Log out?', ok: 'Log out')) return;
    _stream.stop();
    await Siren.stop();
    await Api.I.logout();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final list = _filter == 'All' ? _alerts : _alerts.where((a) => a['status'] == _filter).toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text('SafeHer Admin', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          Tooltip(
            message: _connected ? 'Live connection active' : 'Reconnecting…',
            child: Row(children: [
              Icon(Icons.circle, size: 10, color: _connected ? AppColors.ok : AppColors.warn),
              const SizedBox(width: 4),
              Text(_connected ? 'Live' : 'Offline', style: const TextStyle(fontSize: 12)),
            ]),
          ),
          IconButton(
            tooltip: _soundOn ? 'Alert sound ON (tap to turn off)' : 'Alert sound OFF (tap to turn on)',
            icon: Icon(_soundOn ? Icons.volume_up : Icons.volume_off, color: _soundOn ? AppColors.ok : AppColors.grey),
            onPressed: _toggleSound,
          ),
          IconButton(tooltip: 'Log out', icon: const Icon(Icons.logout), onPressed: _logout),
        ],
      ),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(padding: const EdgeInsets.all(16), children: [
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 2.1,
                  children: [
                    _stat('Total Users', _stats['totalUsers'], Icons.people_outline),
                    _stat('Active Alerts', _stats['active'], Icons.warning_amber_rounded, color: AppColors.red),
                    _stat('Resolved', _stats['resolved'], Icons.verified_outlined, color: AppColors.ok),
                    _stat('Emergency Contacts', _stats['contacts'], Icons.contact_phone_outlined),
                  ],
                ),
                const SizedBox(height: 18),
                const Text('Emergency Alerts', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(children: [
                    for (final f in ['All', 'Pending', 'Responded', 'Resolved', 'Cancelled'])
                      Padding(padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(label: Text(f), selected: _filter == f, onSelected: (_) => setState(() => _filter = f))),
                  ]),
                ),
                const SizedBox(height: 12),
                if (list.isEmpty)
                  const SectionCard(child: EmptyState(icon: Icons.inbox_outlined, title: 'No alerts', text: 'New SOS alerts appear here instantly.'))
                else
                  ...list.map(_alertCard),
                const SizedBox(height: 24),
              ]),
            ),
    );
  }

  Widget _stat(String label, dynamic value, IconData icon, {Color color = AppColors.primary}) => SectionCard(
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          Icon(icon, color: color),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text('${value ?? 0}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              Text(label, style: const TextStyle(color: AppColors.grey, fontSize: 12), overflow: TextOverflow.ellipsis),
            ]),
          ),
        ]),
      );

  Widget _alertCard(Map<String, dynamic> a) {
    final id = (a['id'] as num).toInt();
    final user = Map<String, dynamic>.from(a['user'] as Map? ?? {});
    final isNew = _newIds.contains(id);
    String? liveText;
    Color liveColor = AppColors.ok;
    if (isOpenStatus(a['status'] as String?) && a['locationUpdatedAt'] != null) {
      if (isManual(a)) {
        liveText = '📌 Set by user · ${agoText(a['locationUpdatedAt'] as String)}';
      } else if (liveNow(a)) {
        liveText = '● Live · ${agoText(a['locationUpdatedAt'] as String)}';
      } else {
        liveText = 'Signal lost · last seen ${agoText(a['locationUpdatedAt'] as String)}';
        liveColor = AppColors.grey;
      }
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SectionCard(
        color: isNew ? const Color(0xFFFDE8EA) : null,
        padding: const EdgeInsets.all(14),
        child: InkWell(
          onTap: () => _open(id),
          child: Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  if (isNew) const Padding(padding: EdgeInsets.only(right: 6), child: StatusChip('NEW')),
                  Flexible(child: Text('${user['name'] ?? 'User'}  ·  #$id', style: const TextStyle(fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis)),
                ]),
                const SizedBox(height: 2),
                Text(fmtDateTime(a['createdAt'] as String), style: const TextStyle(color: AppColors.grey, fontSize: 12)),
                Text('${(a['lat'] as num).toStringAsFixed(4)}, ${(a['lng'] as num).toStringAsFixed(4)}${isApprox(a) ? '  ≈ approx' : ''}',
                    style: const TextStyle(fontSize: 13)),
                if (liveText != null) Text(liveText, style: TextStyle(color: liveColor, fontWeight: FontWeight.w700, fontSize: 12)),
              ]),
            ),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              StatusChip(a['status'] as String),
              IconButton(
                  tooltip: 'Call ${user['name'] ?? 'user'}',
                  icon: const Icon(Icons.call, color: AppColors.ok),
                  onPressed: user['phone'] == null ? null : () => launchUrl(Uri.parse('tel:${user['phone']}'))),
            ]),
          ]),
        ),
      ),
    );
  }
}
