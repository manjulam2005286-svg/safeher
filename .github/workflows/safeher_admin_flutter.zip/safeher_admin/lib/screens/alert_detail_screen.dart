import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../theme.dart';
import '../widgets/common.dart';

class AlertDetailScreen extends StatefulWidget {
  final int alertId;
  const AlertDetailScreen({super.key, required this.alertId});
  @override
  State<AlertDetailScreen> createState() => _AlertDetailScreenState();
}

class _AlertDetailScreenState extends State<AlertDetailScreen> {
  Map<String, dynamic>? _a;
  final _map = MapController();
  bool _mapReady = false, _follow = true, _saving = false;
  String? _newStatus;
  LatLng? _lastCenter;
  Timer? _poll, _tick;

  @override
  void initState() {
    super.initState();
    _load();
    _poll = Timer.periodic(const Duration(seconds: 4), (_) => _load());
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _poll?.cancel();
    _tick?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final a = await Api.I.alert(widget.alertId);
      if (!mounted) return;
      setState(() {
        _a = a;
        _newStatus ??= a['status'] == 'Cancelled' ? null : a['status'] as String;
      });
      final p = LatLng((a['lat'] as num).toDouble(), (a['lng'] as num).toDouble());
      if (_mapReady && _follow && _lastCenter != p) _map.move(p, _map.camera.zoom);
      _lastCenter = p;
    } on ApiException catch (e) {
      if (mounted && e.status != 401) toast(context, e.message, error: true);
    }
  }

  Future<void> _save() async {
    final s = _newStatus;
    if (s == null) return;
    setState(() => _saving = true);
    try {
      await Api.I.setStatus(widget.alertId, s);
      if (mounted) toast(context, 'Status updated to $s.');
      await _load();
    } on ApiException catch (e) {
      if (mounted) toast(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final a = _a;
    if (a == null) return Scaffold(appBar: AppBar(title: Text('Alert #${widget.alertId}')), body: const Center(child: CircularProgressIndicator()));
    final user = Map<String, dynamic>.from(a['user'] as Map? ?? {});
    final contacts = List<Map<String, dynamic>>.from(a['contacts'] as List? ?? []);
    final cur = LatLng((a['lat'] as num).toDouble(), (a['lng'] as num).toDouble());
    final trail = (a['trail'] as List? ?? []).map((p) => LatLng(((p as Map)['lat'] as num).toDouble(), (p['lng'] as num).toDouble())).toList();
    final start = a['startLat'] != null ? LatLng((a['startLat'] as num).toDouble(), (a['startLng'] as num).toDouble()) : null;
    final open = isOpenStatus(a['status'] as String?);
    final String tag = !open ? 'Not live (alert closed)' : isManual(a) ? '📌 Exact location (set by user)' : liveNow(a) ? '● LIVE' : '⚠ Signal lost';

    return Scaffold(
      appBar: AppBar(title: Text('Alert #${a['id']}'), actions: [Padding(padding: const EdgeInsets.only(right: 12), child: Center(child: StatusChip(a['status'] as String)))]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        SectionCard(
          title: '👤 User',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${user['name'] ?? ''}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text('📞 ${user['phone'] ?? ''}    ✉ ${user['email'] ?? ''}'),
            Text('🕒 Raised ${fmtDateTime(a['createdAt'] as String)}', style: const TextStyle(color: AppColors.grey)),
            Text('💬 ${a['message'] ?? ''}', style: const TextStyle(color: AppColors.grey)),
            const SizedBox(height: 10),
            Wrap(spacing: 8, children: [
              FilledButton.icon(onPressed: () => launchUrl(Uri.parse('tel:${user['phone']}')), icon: const Icon(Icons.call), label: const Text('Call user')),
              OutlinedButton.icon(onPressed: () => launchUrl(Uri.parse('mailto:${user['email']}')), icon: const Icon(Icons.mail_outline), label: const Text('Email')),
            ]),
          ]),
        ),
        const SizedBox(height: 16),
        SectionCard(
          title: '📍 ${open ? 'Live location' : 'Last known location'}',
          trailing: StatusChip(tag),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: SizedBox(
                height: 320,
                child: FlutterMap(
                  mapController: _map,
                  options: MapOptions(
                    initialCenter: cur,
                    initialZoom: 16,
                    onMapReady: () => _mapReady = true,
                    onPositionChanged: (_, hasGesture) {
                      if (hasGesture && _follow) setState(() => _follow = false);
                    },
                  ),
                  children: [
                    TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.safeher.safeher_admin'),
                    if (trail.length > 1) PolylineLayer(polylines: [Polyline(points: trail, strokeWidth: 4, color: AppColors.violet)]),
                    MarkerLayer(markers: [
                      if (start != null && start != cur)
                        Marker(point: start, width: 22, height: 22, child: const Icon(Icons.trip_origin, color: AppColors.ok, size: 22)),
                      Marker(point: cur, width: 48, height: 48, alignment: Alignment.topCenter, child: const Icon(Icons.location_pin, color: AppColors.red, size: 48)),
                    ]),
                    const RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap contributors')]),
                  ],
                ),
              ),
            ),
            if (!_follow)
              TextButton.icon(
                  onPressed: () {
                    setState(() => _follow = true);
                    if (_mapReady) _map.move(cur, 16);
                  },
                  icon: const Icon(Icons.my_location),
                  label: const Text('Follow live position')),
            const SizedBox(height: 8),
            Text('${cur.latitude.toStringAsFixed(6)}, ${cur.longitude.toStringAsFixed(6)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            Text(
                'Updated ${agoText(a['locationUpdatedAt'] as String?)}'
                '${a['accuracy'] is num ? ' · accuracy ${accuracyText(a['accuracy'] as num)}' : ''}'
                ' · ${trail.length} location updates',
                style: const TextStyle(color: AppColors.grey, fontSize: 12)),
            if (isApprox(a)) WarnBox("⚠ Approximate location (${accuracyText(a['accuracy'] as num)}). The sender's device has no precise GPS fix."),
            if (isManual(a)) WarnBox('📌 Exact location set by the user: ${a['locationLabel']}', good: true),
            const SizedBox(height: 6),
            OutlinedButton.icon(
                onPressed: () => launchUrl(Uri.parse('https://www.google.com/maps?q=${cur.latitude},${cur.longitude}'), mode: LaunchMode.externalApplication),
                icon: const Icon(Icons.directions),
                label: const Text('Open in Google Maps / Directions')),
          ]),
        ),
        const SizedBox(height: 16),
        SectionCard(
          title: '👥 Emergency contacts',
          child: contacts.isEmpty
              ? const Text('No contacts on file.', style: TextStyle(color: AppColors.grey))
              : Column(
                  children: contacts
                      .map((c) => ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: Text('${c['name']}${c['primary'] == true ? ' · Primary' : ''}'),
                            subtitle: Text('${c['relationship']} · ${c['phone']}'),
                            trailing: IconButton(tooltip: 'Call ${c['name']}', icon: const Icon(Icons.call, color: AppColors.ok),
                                onPressed: () => launchUrl(Uri.parse('tel:${c['phone']}'))),
                          ))
                      .toList()),
        ),
        const SizedBox(height: 16),
        SectionCard(
          title: '🛠 Update status',
          child: a['status'] == 'Cancelled'
              ? const Text('Cancelled by the user. No action needed.', style: TextStyle(color: AppColors.grey))
              : Row(children: [
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _newStatus,
                      decoration: const InputDecoration(labelText: 'Status', isDense: true),
                      items: const ['Pending', 'Responded', 'Resolved'].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
                      onChanged: (v) => setState(() => _newStatus = v),
                    ),
                  ),
                  const SizedBox(width: 10),
                  FilledButton(onPressed: _saving || _newStatus == a['status'] ? null : _save, child: Text(_saving ? 'Saving…' : 'Update')),
                ]),
        ),
        const SizedBox(height: 24),
      ]),
    );
  }
}
