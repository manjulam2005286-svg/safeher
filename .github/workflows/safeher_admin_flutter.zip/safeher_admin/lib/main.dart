import 'package:flutter/material.dart';
import 'api.dart';
import 'theme.dart';
import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';

final navKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Api.I.init();
  Api.I.onSessionExpired = () => navKey.currentState
      ?.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen(message: 'Session expired. Please log in again.')), (_) => false);
  runApp(const SafeHerAdminApp());
}

class SafeHerAdminApp extends StatelessWidget {
  const SafeHerAdminApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'SafeHer Admin',
        debugShowCheckedModeBanner: false,
        navigatorKey: navKey,
        theme: buildTheme(),
        home: Api.I.loggedIn ? const DashboardScreen() : const LoginScreen(),
      );
}
