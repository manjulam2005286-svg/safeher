import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiException implements Exception {
  final String message;
  final int status;
  ApiException(this.message, [this.status = 0]);
  @override
  String toString() => message;
}

/// Admin client for the existing SafeHer Node.js/Express backend.
class Api {
  Api._();
  static final Api I = Api._();

  late SharedPreferences prefs;
  String baseUrl = '';
  String? token;
  Map<String, dynamic>? admin;
  void Function()? onSessionExpired;

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    baseUrl = prefs.getString('server') ?? 'http://192.168.1.10:5050';
    token = prefs.getString('token');
    final a = prefs.getString('admin');
    if (a != null) admin = jsonDecode(a) as Map<String, dynamic>;
  }

  bool get loggedIn => token != null;

  Future<void> setServer(String url) async {
    var u = url.trim().replaceAll(RegExp(r'/+$'), '');
    if (u.isNotEmpty && !u.startsWith('http')) u = 'http://$u';
    baseUrl = u;
    await prefs.setString('server', baseUrl);
  }

  Future<dynamic> _req(String method, String path, [Object? body]) async {
    final uri = Uri.parse('$baseUrl/api$path');
    final headers = {'Content-Type': 'application/json', if (token != null) 'Authorization': token!};
    http.Response r;
    try {
      final f = method == 'POST'
          ? http.post(uri, headers: headers, body: jsonEncode(body))
          : method == 'PUT'
              ? http.put(uri, headers: headers, body: jsonEncode(body))
              : http.get(uri, headers: headers);
      r = await f.timeout(const Duration(seconds: 15));
    } catch (_) {
      throw ApiException("Can't reach the SafeHer server at $baseUrl.");
    }
    dynamic d;
    try {
      d = r.body.isEmpty ? null : jsonDecode(r.body);
    } catch (_) {}
    if (r.statusCode == 401 && !path.startsWith('/auth/')) {
      await logout();
      onSessionExpired?.call();
      throw ApiException('Session expired. Please log in again.', 401);
    }
    if (r.statusCode >= 400) throw ApiException(d is Map && d['error'] != null ? d['error'].toString() : 'Error ${r.statusCode}', r.statusCode);
    return d;
  }

  Future<void> login(String email, String password) async {
    final d = Map<String, dynamic>.from(await _req('POST', '/auth/login', {'email': email, 'password': password, 'role': 'admin'}) as Map);
    if (d['role'] != 'admin') throw ApiException('This account is not an admin account.');
    token = d['token'] as String;
    admin = Map<String, dynamic>.from(d['user'] as Map);
    await prefs.setString('token', token!);
    await prefs.setString('admin', jsonEncode(admin));
  }

  Future<void> logout() async {
    token = null;
    admin = null;
    await prefs.remove('token');
    await prefs.remove('admin');
  }

  Future<Map<String, dynamic>> dashboard() async => Map<String, dynamic>.from(await _req('GET', '/admin/dashboard') as Map);
  Future<List<Map<String, dynamic>>> alerts() async => List<Map<String, dynamic>>.from(await _req('GET', '/admin/alerts') as List);
  Future<Map<String, dynamic>> alert(int id) async => Map<String, dynamic>.from(await _req('GET', '/emergency/detail/$id') as Map);
  Future<void> setStatus(int id, String status) => _req('PUT', '/admin/alerts/$id/status', {'status': status});

  String get streamUrl => '$baseUrl/api/admin/stream?token=$token';
}

bool isOpenStatus(String? s) => s == 'Pending' || s == 'Responded';
bool isManual(Map a) => a['locationSource'] == 'manual';

/// Fresh location point in the last 60 seconds.
bool liveNow(Map a) {
  if (!isOpenStatus(a['status'] as String?)) return false;
  final t = DateTime.tryParse((a['locationUpdatedAt'] ?? '') as String);
  return t != null && DateTime.now().difference(t.toLocal()).inSeconds < 60;
}

bool isApprox(Map a) => !isManual(a) && a['accuracy'] is num && (a['accuracy'] as num) > 500;
String accuracyText(num acc) => acc >= 1000 ? '±${(acc / 1000).toStringAsFixed(1)} km' : '±${acc.round()} m';
