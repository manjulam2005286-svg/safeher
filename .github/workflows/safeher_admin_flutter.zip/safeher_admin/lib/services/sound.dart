import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';

/// Generates a siren as a WAV file (no audio asset needed) and loops it.
class Siren {
  Siren._();
  static final AudioPlayer _p = AudioPlayer();
  static bool playing = false;

  static Uint8List _wav() {
    const rate = 16000, secs = 2;
    final n = rate * secs;
    final data = ByteData(44 + n * 2);
    void str(int o, String s) {
      for (var i = 0; i < s.length; i++) {
        data.setUint8(o + i, s.codeUnitAt(i));
      }
    }
    str(0, 'RIFF');
    data.setUint32(4, 36 + n * 2, Endian.little);
    str(8, 'WAVE');
    str(12, 'fmt ');
    data.setUint32(16, 16, Endian.little);
    data.setUint16(20, 1, Endian.little);
    data.setUint16(22, 1, Endian.little);
    data.setUint32(24, rate, Endian.little);
    data.setUint32(28, rate * 2, Endian.little);
    data.setUint16(32, 2, Endian.little);
    data.setUint16(34, 16, Endian.little);
    str(36, 'data');
    data.setUint32(40, n * 2, Endian.little);
    var phase = 0.0;
    for (var i = 0; i < n; i++) {
      final t = i / rate;
      final tri = 1 - (2 * ((t % 1.0) - 0.5)).abs() * 2; // -1..1 triangle, 1 cycle per second
      final f = 900 + 350 * tri; // sweeps 550..1250 Hz
      phase += 2 * math.pi * f / rate;
      data.setInt16(44 + i * 2, (math.sin(phase) * 32767 * 0.6).round(), Endian.little);
    }
    return data.buffer.asUint8List();
  }

  static Future<void> start() async {
    if (playing) return;
    playing = true;
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/siren.wav');
    if (!await f.exists()) await f.writeAsBytes(_wav());
    await _p.setReleaseMode(ReleaseMode.loop);
    await _p.play(DeviceFileSource(f.path));
  }

  static Future<void> stop() async {
    playing = false;
    await _p.stop();
  }
}
