import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../api.dart';

/// Listens to the server's Server-Sent Events stream (/api/admin/stream).
/// Events: "sos" (new alert), "location" (live location update), "cancel" (user cancelled).
/// Reconnects automatically every 3 seconds if the connection drops.
class AdminStream {
  final void Function(String event, Map<String, dynamic> data) onEvent;
  final void Function(bool connected) onStatus;
  final void Function() onUnauthorized;
  http.Client? _client;
  Timer? _retry;
  bool _closed = false;

  AdminStream({required this.onEvent, required this.onStatus, required this.onUnauthorized});

  void start() {
    _closed = false;
    _connect();
  }

  Future<void> _connect() async {
    if (_closed) return;
    _client?.close();
    final client = http.Client();
    _client = client;
    try {
      final req = http.Request('GET', Uri.parse(Api.I.streamUrl))..headers['Accept'] = 'text/event-stream';
      final res = await client.send(req);
      if (res.statusCode == 401) {
        onUnauthorized();
        return;
      }
      onStatus(true);
      var event = 'message';
      final data = StringBuffer();
      await for (final line in res.stream.transform(utf8.decoder).transform(const LineSplitter())) {
        if (line.isEmpty) {
          if (data.isNotEmpty) {
            try {
              onEvent(event, Map<String, dynamic>.from(jsonDecode(data.toString()) as Map));
            } catch (_) {}
          }
          event = 'message';
          data.clear();
        } else if (line.startsWith(':')) {
          // comment / keep-alive ping
        } else if (line.startsWith('event:')) {
          event = line.substring(6).trim();
        } else if (line.startsWith('data:')) {
          if (data.isNotEmpty) data.write('\n');
          data.write(line.substring(5).trim());
        }
      }
    } catch (_) {}
    onStatus(false);
    if (!_closed) _retry = Timer(const Duration(seconds: 3), _connect);
  }

  void stop() {
    _closed = true;
    _retry?.cancel();
    _client?.close();
  }
}
