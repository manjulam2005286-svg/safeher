import 'package:flutter/material.dart';
import 'api.dart';
import 'theme.dart';
import 'screens/login_screen.dart';
import 'screens/home_shell.dart';

final navKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Api.I.init();
  Api.I.onSessionExpired = () => navKey.currentState
      ?.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen(message: 'Session expired. Please log in again.')), (_) => false);
  runApp(const SafeHerApp());
}

class SafeHerApp extends StatelessWidget {
  const SafeHerApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'SafeHer',
        debugShowCheckedModeBanner: false,
        navigatorKey: navKey,
        theme: buildTheme(),
        home: Api.I.loggedIn ? const HomeShell() : const LoginScreen(),
      );
}
