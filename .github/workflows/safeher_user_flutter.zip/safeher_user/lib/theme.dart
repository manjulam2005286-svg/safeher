import 'package:flutter/material.dart';

/// SafeHer brand colours (same as the web app).
class AppColors {
  static const primary = Color(0xFF4C2BB8);
  static const violet = Color(0xFF7A5AF8);
  static const soft = Color(0xFFF1EEFF);
  static const bg = Color(0xFFF8F7FD);
  static const ink = Color(0xFF14123A);
  static const grey = Color(0xFF6B6A85);
  static const line = Color(0xFFE7E5F4);
  static const red = Color(0xFFE11D48);
  static const ok = Color(0xFF16A34A);
  static const warn = Color(0xFFD97706);
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(seedColor: AppColors.primary, primary: AppColors.primary, error: AppColors.red, surface: Colors.white);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: AppColors.bg,
    appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: AppColors.ink, elevation: 0, centerTitle: false),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(minimumSize: const Size(48, 48),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)))),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(minimumSize: const Size(48, 48),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)))),
  );
}
