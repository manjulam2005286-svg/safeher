import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme.dart';

/// Press and hold for 3 seconds to trigger. Releasing early cancels (prevents accidental alerts).
class SosButton extends StatefulWidget {
  final VoidCallback onTriggered;
  final bool busy;
  final double size;
  const SosButton({super.key, required this.onTriggered, this.busy = false, this.size = 180});
  @override
  State<SosButton> createState() => _SosButtonState();
}

class _SosButtonState extends State<SosButton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 3))
    ..addStatusListener((s) {
      if (s == AnimationStatus.completed) {
        HapticFeedback.heavyImpact();
        _c.reset();
        widget.onTriggered();
      }
    });

  void _down() {
    if (widget.busy) return;
    HapticFeedback.mediumImpact();
    _c.forward(from: 0);
  }

  void _up() {
    if (_c.isAnimating) _c.reset();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    return Semantics(
      button: true,
      label: 'Emergency SOS. Press and hold for 3 seconds',
      child: GestureDetector(
        onTapDown: (_) => _down(),
        onTapUp: (_) => _up(),
        onTapCancel: _up,
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) => SizedBox(
            width: s + 40,
            height: s + 40,
            child: Stack(alignment: Alignment.center, children: [
              Container(
                width: s + 40,
                height: s + 40,
                decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.red.withOpacity(0.08)),
              ),
              SizedBox(
                width: s + 16,
                height: s + 16,
                child: CircularProgressIndicator(
                    value: _c.value, strokeWidth: 8, color: AppColors.red, backgroundColor: AppColors.red.withOpacity(0.12)),
              ),
              AnimatedScale(
                scale: _c.isAnimating ? 0.94 : 1,
                duration: const Duration(milliseconds: 150),
                child: Container(
                  width: s,
                  height: s,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: widget.busy ? AppColors.red.withOpacity(0.6) : AppColors.red,
                    boxShadow: [BoxShadow(color: AppColors.red.withOpacity(0.35), blurRadius: 24, offset: const Offset(0, 8))],
                  ),
                  alignment: Alignment.center,
                  child: widget.busy
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('SOS', style: TextStyle(color: Colors.white, fontSize: 40, fontWeight: FontWeight.w800, letterSpacing: 2)),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
