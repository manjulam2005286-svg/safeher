import 'package:flutter/material.dart';
import '../api.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'home_shell.dart';
import 'register_screen.dart';

/// Server address field is shown here because the phone talks to the laptop running the
/// SafeHer Node.js server over Wi-Fi (for example http://192.168.1.10:5050).
class ServerField extends StatefulWidget {
  const ServerField({super.key});
  @override
  State<ServerField> createState() => _ServerFieldState();
}

class _ServerFieldState extends State<ServerField> {
  late final _c = TextEditingController(text: Api.I.baseUrl);
  @override
  Widget build(BuildContext context) => ExpansionTile(
        tilePadding: EdgeInsets.zero,
        leading: const Icon(Icons.dns_outlined),
        title: const Text('Server settings'),
        subtitle: Text(Api.I.baseUrl, style: const TextStyle(fontSize: 12)),
        children: [
          TextField(
            controller: _c,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(labelText: 'Server address', hintText: 'http://192.168.1.10:5050'),
            onSubmitted: (v) async {
              await Api.I.setServer(v);
              setState(() {});
            },
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
                onPressed: () async {
                  await Api.I.setServer(_c.text);
                  if (context.mounted) toast(context, 'Server saved: ${Api.I.baseUrl}');
                  setState(() {});
                },
                child: const Text('Save server')),
          ),
        ],
      );
}

class LoginScreen extends StatefulWidget {
  final String? message;
  const LoginScreen({super.key, this.message});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController(), _pw = TextEditingController();
  bool _busy = false;
  String? _err;

  @override
  void initState() {
    super.initState();
    _err = widget.message;
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _err = null;
    });
    try {
      await Api.I.login(_email.text.trim(), _pw.text);
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomeShell()), (_) => false);
    } on ApiException catch (e) {
      setState(() => _err = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Form(
                  key: _form,
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const Icon(Icons.shield_moon, size: 64, color: AppColors.primary),
                    const SizedBox(height: 8),
                    const Text('SafeHer', textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: AppColors.ink)),
                    const Text('Your safety companion', textAlign: TextAlign.center, style: TextStyle(color: AppColors.grey)),
                    const SizedBox(height: 28),
                    TextFormField(
                        controller: _email,
                        keyboardType: TextInputType.emailAddress,
                        autofillHints: const [AutofillHints.email],
                        decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.mail_outline)),
                        validator: (v) => (v ?? '').contains('@') ? null : 'Enter a valid email'),
                    const SizedBox(height: 12),
                    TextFormField(
                        controller: _pw,
                        obscureText: true,
                        decoration: const InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock_outline)),
                        validator: (v) => (v ?? '').isEmpty ? 'Enter your password' : null,
                        onFieldSubmitted: (_) => _submit()),
                    if (_err != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_err!, style: const TextStyle(color: AppColors.red))),
                    const SizedBox(height: 18),
                    FilledButton(
                        onPressed: _busy ? null : _submit,
                        child: _busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Log in')),
                    const SizedBox(height: 8),
                    TextButton(
                        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterScreen())),
                        child: const Text('New here? Create an account')),
                    const SizedBox(height: 8),
                    const ServerField(),
                  ]),
                ),
              ),
            ),
          ),
        ),
      );
}
