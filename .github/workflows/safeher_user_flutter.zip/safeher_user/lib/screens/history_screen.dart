import 'package:flutter/material.dart';
import '../api.dart';
import '../widgets/common.dart';
import 'emergency_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<Map<String, dynamic>>? _list;
  String _filter = 'All';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.I.alerts();
      if (mounted) setState(() => _list = l);
    } on ApiException catch (e) {
      if (mounted) {
        setState(() => _list ??= []);
        toast(context, e.message, error: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final all = _list;
    if (all == null) return const Center(child: CircularProgressIndicator());
    final l = _filter == 'All' ? all : all.where((a) => a['status'] == _filter).toList();
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Wrap(spacing: 8, children: [
          for (final f in ['All', 'Pending', 'Responded', 'Resolved', 'Cancelled'])
            ChoiceChip(label: Text(f), selected: _filter == f, onSelected: (_) => setState(() => _filter = f)),
        ]),
        const SizedBox(height: 12),
        if (l.isEmpty)
          const SectionCard(child: EmptyState(icon: Icons.history, title: 'No alerts here', text: 'Alerts you raise with SOS will appear here with their full details.'))
        else
          ...l.map((a) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: SectionCard(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                  child: ListTile(
                    title: Text('Alert #${a['id']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text('${fmtDateTime(a['createdAt'] as String)}\n${(a['lat'] as num).toStringAsFixed(4)}, ${(a['lng'] as num).toStringAsFixed(4)}'),
                    isThreeLine: true,
                    trailing: StatusChip(a['status'] as String),
                    onTap: () async {
                      await Navigator.push(context, MaterialPageRoute(builder: (_) => EmergencyScreen(alertId: (a['id'] as num).toInt())));
                      _load();
                    },
                  ),
                ),
              )),
      ]),
    );
  }
}
