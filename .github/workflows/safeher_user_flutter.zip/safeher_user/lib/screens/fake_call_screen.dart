import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/sound.dart';

/// Simulated incoming call to help the user step away from an uncomfortable situation.
class FakeCallScreen extends StatefulWidget {
  const FakeCallScreen({super.key});
  @override
  State<FakeCallScreen> createState() => _FakeCallScreenState();
}

class _FakeCallScreenState extends State<FakeCallScreen> {
  static const _callers = ['Mom', 'Dad', 'Friend', 'Office'];
  String _caller = 'Mom';
  bool _accepted = false;
  int _secs = 0;
  Timer? _t, _buzz;

  @override
  void initState() {
    super.initState();
    Sound.ring();
    _buzz = Timer.periodic(const Duration(seconds: 3), (_) => HapticFeedback.vibrate());
  }

  void _accept() {
    Sound.stop();
    _buzz?.cancel();
    setState(() => _accepted = true);
    _t = Timer.periodic(const Duration(seconds: 1), (_) => setState(() => _secs++));
  }

  void _end() => Navigator.pop(context);

  @override
  void dispose() {
    Sound.stop();
    _t?.cancel();
    _buzz?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mm = (_secs ~/ 60).toString().padLeft(2, '0'), ss = (_secs % 60).toString().padLeft(2, '0');
    return Scaffold(
      backgroundColor: const Color(0xFF14123A),
      body: SafeArea(
        child: Column(children: [
          const SizedBox(height: 16),
          if (!_accepted)
            DropdownButton<String>(
              value: _caller,
              dropdownColor: const Color(0xFF2A2760),
              style: const TextStyle(color: Colors.white),
              underline: const SizedBox(),
              items: _callers.map((c) => DropdownMenuItem(value: c, child: Text('Caller: $c'))).toList(),
              onChanged: (v) => setState(() => _caller = v ?? _caller),
            ),
          const Spacer(),
          CircleAvatar(radius: 56, backgroundColor: Colors.white12, child: Text(_caller[0], style: const TextStyle(fontSize: 44, color: Colors.white))),
          const SizedBox(height: 16),
          Text(_caller, style: const TextStyle(fontSize: 34, color: Colors.white, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text(_accepted ? '$mm:$ss' : 'Incoming call…', style: const TextStyle(color: Colors.white70, fontSize: 16)),
          const Spacer(flex: 2),
          Padding(
            padding: const EdgeInsets.only(bottom: 48),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              _round(Icons.call_end, Colors.red, _accepted ? 'End' : 'Decline', _end),
              if (!_accepted) _round(Icons.call, Colors.green, 'Accept', _accept),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _round(IconData icon, Color c, String label, VoidCallback onTap) => Column(children: [
        Material(
          color: c,
          shape: const CircleBorder(),
          child: InkWell(customBorder: const CircleBorder(), onTap: onTap,
              child: Padding(padding: const EdgeInsets.all(20), child: Icon(icon, color: Colors.white, size: 34))),
        ),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(color: Colors.white70)),
      ]);
}
