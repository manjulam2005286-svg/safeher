import 'package:flutter/material.dart';
import '../api.dart';
import '../widgets/common.dart';
import 'home_shell.dart';

const relationships = ['Mother', 'Father', 'Sister', 'Brother', 'Spouse', 'Friend', 'Relative', 'Other'];
String? phoneValidator(String? v) => RegExp(r'^\d{10}$').hasMatch(v ?? '') ? null : 'Enter a 10-digit phone number';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController(), _email = TextEditingController(), _phone = TextEditingController();
  final _pw = TextEditingController(), _pw2 = TextEditingController(), _cName = TextEditingController(), _cPhone = TextEditingController();
  String _rel = 'Mother';
  bool _busy = false;

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      await Api.I.register({
        'name': _name.text.trim(),
        'email': _email.text.trim(),
        'phone': _phone.text.trim(),
        'password': _pw.text,
        'contactName': _cName.text.trim(),
        'contactPhone': _cPhone.text.trim(),
        'relationship': _rel,
      });
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomeShell()), (_) => false);
    } on ApiException catch (e) {
      if (mounted) toast(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _gap() => const SizedBox(height: 12);

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Create account')),
        body: Form(
          key: _form,
          child: ListView(padding: const EdgeInsets.all(20), children: [
            TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Full name'),
                validator: (v) => (v ?? '').trim().isEmpty ? 'Enter your name' : null),
            _gap(),
            TextFormField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email'),
                validator: (v) => RegExp(r'^\S+@\S+\.\S+$').hasMatch(v ?? '') ? null : 'Enter a valid email'),
            _gap(),
            TextFormField(controller: _phone, keyboardType: TextInputType.phone, maxLength: 10, decoration: const InputDecoration(labelText: 'Phone (10 digits)'),
                validator: phoneValidator),
            TextFormField(controller: _pw, obscureText: true, decoration: const InputDecoration(labelText: 'Password (min 6 characters)'),
                validator: (v) => (v ?? '').length < 6 ? 'At least 6 characters' : null),
            _gap(),
            TextFormField(controller: _pw2, obscureText: true, decoration: const InputDecoration(labelText: 'Confirm password'),
                validator: (v) => v != _pw.text ? 'Passwords do not match' : null),
            const SizedBox(height: 24),
            const Text('Emergency contact', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const Text('Someone you trust. You can add more later.', style: TextStyle(color: Colors.black54)),
            _gap(),
            TextFormField(controller: _cName, decoration: const InputDecoration(labelText: 'Contact name'),
                validator: (v) => (v ?? '').trim().isEmpty ? 'Enter contact name' : null),
            _gap(),
            TextFormField(controller: _cPhone, keyboardType: TextInputType.phone, maxLength: 10, decoration: const InputDecoration(labelText: 'Contact phone (10 digits)'),
                validator: phoneValidator),
            DropdownButtonFormField<String>(
              value: _rel,
              decoration: const InputDecoration(labelText: 'Relationship'),
              items: relationships.map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(),
              onChanged: (v) => setState(() => _rel = v ?? _rel),
            ),
            const SizedBox(height: 24),
            FilledButton(onPressed: _busy ? null : _submit, child: Text(_busy ? 'Creating account…' : 'Create account')),
          ]),
        ),
      );
}
