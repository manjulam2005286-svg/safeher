import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import '../services/location.dart';
import '../theme.dart';

class PickedLocation {
  final double lat, lng;
  final String label;
  const PickedLocation(this.lat, this.lng, this.label);
}

/// Exact-location picker: search a place (OpenStreetMap Nominatim), paste a Google Maps
/// link / coordinates, or tap the map. Used when the device's location is only approximate.
class LocationPickerScreen extends StatefulWidget {
  final String title;
  final String? intro;
  final ({double lat, double lng})? start;
  const LocationPickerScreen({super.key, this.title = 'Set your exact location', this.intro, this.start});
  @override
  State<LocationPickerScreen> createState() => _LocationPickerScreenState();
}

class _LocationPickerScreenState extends State<LocationPickerScreen> {
  final _map = MapController();
  final _q = TextEditingController();
  LatLng? _sel;
  String _label = '', _place = '', _msg = '';
  List<Map<String, dynamic>> _results = [];
  bool _searching = false;

  void _choose(LatLng p, String label, {double? zoom}) {
    setState(() {
      _sel = p;
      _label = label;
    });
    if (zoom != null) _map.move(p, zoom);
  }

  Future<void> _search() async {
    final text = _q.text.trim();
    FocusScope.of(context).unfocus();
    if (text.isEmpty) return;
    final c = parseCoords(text);
    if (c != null) {
      _place = '';
      setState(() {
        _results = [];
        _msg = 'Location recognised.';
      });
      _choose(LatLng(c.lat, c.lng), text.startsWith('http') ? 'From Google Maps link' : 'Coordinates you entered', zoom: 17);
      return;
    }
    setState(() {
      _searching = true;
      _msg = 'Searching…';
    });
    try {
      final r = await http.get(
          Uri.parse('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&q=${Uri.encodeComponent(text)}'),
          headers: {'User-Agent': 'SafeHer/1.0 (women safety app)', 'Accept-Language': 'en'}).timeout(const Duration(seconds: 12));
      final list = List<Map<String, dynamic>>.from(jsonDecode(r.body) as List);
      setState(() {
        _results = list;
        _msg = list.isEmpty ? 'No places found. Add the area or city name, or tap the map.' : 'Choose a result:';
      });
    } catch (_) {
      setState(() => _msg = 'Place search is unavailable. Paste coordinates or a Google Maps link instead.');
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final start = widget.start;
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.intro ?? 'Search for a place, paste a Google Maps link or coordinates, or tap your position on the map.',
                style: const TextStyle(color: AppColors.grey)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                child: TextField(
                  controller: _q,
                  textInputAction: TextInputAction.search,
                  onSubmitted: (_) => _search(),
                  decoration: const InputDecoration(isDense: true, hintText: 'Area, landmark, Maps link or 10.99, 76.95', prefixIcon: Icon(Icons.search)),
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(onPressed: _searching ? null : _search, child: const Text('Search')),
            ]),
            if (_msg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(_msg, style: const TextStyle(fontSize: 12, color: AppColors.grey))),
          ]),
        ),
        if (_results.isNotEmpty)
          ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 220),
            child: ListView(
                shrinkWrap: true,
                children: _results
                    .map((p) => ListTile(
                          dense: true,
                          leading: const Icon(Icons.place_outlined),
                          title: Text(p['display_name'] as String, maxLines: 2, overflow: TextOverflow.ellipsis),
                          onTap: () {
                            _place = (p['display_name'] as String).split(',').take(3).join(',');
                            _choose(LatLng(double.parse(p['lat'] as String), double.parse(p['lon'] as String)), _place, zoom: 17);
                            setState(() {
                              _results = [];
                              _msg = 'Place selected. Tap the map to adjust the pin if needed.';
                            });
                          },
                        ))
                    .toList()),
          ),
        const SizedBox(height: 8),
        Expanded(
          child: FlutterMap(
            mapController: _map,
            options: MapOptions(
              initialCenter: start != null ? LatLng(start.lat, start.lng) : const LatLng(20.59, 78.96),
              initialZoom: start != null ? 12 : 5,
              onTap: (_, p) => _choose(p, _place.isNotEmpty ? 'Pinned near $_place' : 'Pinned on map'),
            ),
            children: [
              TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.safeher.safeher_user'),
              if (_sel != null)
                MarkerLayer(markers: [
                  Marker(point: _sel!, width: 48, height: 48, alignment: Alignment.topCenter,
                      child: const Icon(Icons.location_pin, color: AppColors.red, size: 48)),
                ]),
              const RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap contributors')]),
            ],
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(_sel == null ? 'No location selected yet.' : 'Selected: $_label\n${_sel!.latitude.toStringAsFixed(6)}, ${_sel!.longitude.toStringAsFixed(6)}',
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 10),
              FilledButton(
                onPressed: _sel == null ? null : () => Navigator.pop(context, PickedLocation(_sel!.latitude, _sel!.longitude, _label)),
                child: const Text('Use this location'),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}
