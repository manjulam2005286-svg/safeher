import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'register_screen.dart' show relationships, phoneValidator;

class ContactsScreen extends StatefulWidget {
  const ContactsScreen({super.key});
  @override
  State<ContactsScreen> createState() => _ContactsScreenState();
}

class _ContactsScreenState extends State<ContactsScreen> {
  List<Map<String, dynamic>>? _list;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.I.contacts();
      if (mounted) setState(() => _list = l);
    } on ApiException catch (e) {
      if (mounted) {
        setState(() => _list ??= []);
        toast(context, e.message, error: true);
      }
    }
  }

  Future<void> _edit([Map<String, dynamic>? c]) async {
    final form = GlobalKey<FormState>();
    final name = TextEditingController(text: c?['name'] as String?), phone = TextEditingController(text: c?['phone'] as String?);
    var rel = (c?['relationship'] as String?) ?? 'Mother';
    if (!relationships.contains(rel)) rel = 'Other';
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + MediaQuery.of(ctx).viewInsets.bottom),
        child: Form(
          key: form,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(c == null ? 'Add emergency contact' : 'Edit contact', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 14),
            TextFormField(controller: name, decoration: const InputDecoration(labelText: 'Name'),
                validator: (v) => (v ?? '').trim().isEmpty ? 'Enter a name' : null),
            const SizedBox(height: 12),
            TextFormField(controller: phone, keyboardType: TextInputType.phone, maxLength: 10,
                decoration: const InputDecoration(labelText: 'Phone (10 digits)'), validator: phoneValidator),
            StatefulBuilder(
              builder: (ctx, set) => DropdownButtonFormField<String>(
                value: rel,
                decoration: const InputDecoration(labelText: 'Relationship'),
                items: relationships.map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(),
                onChanged: (v) => set(() => rel = v ?? rel),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton(onPressed: () {
              if (form.currentState!.validate()) Navigator.pop(ctx, true);
            }, child: Text(c == null ? 'Add contact' : 'Save changes')),
          ]),
        ),
      ),
    );
    if (ok != true) return;
    final data = {'name': name.text.trim(), 'phone': phone.text.trim(), 'relationship': rel};
    try {
      if (c == null) {
        await Api.I.addContact(data);
      } else {
        await Api.I.updateContact((c['id'] as num).toInt(), data);
      }
      if (mounted) toast(context, c == null ? 'Emergency contact added.' : 'Emergency contact updated.');
      _load();
    } on ApiException catch (e) {
      if (mounted) toast(context, e.message, error: true);
    }
  }

  Future<void> _primary(Map<String, dynamic> c) async {
    try {
      await Api.I.updateContact((c['id'] as num).toInt(), {'primary': true});
      if (mounted) toast(context, '${c['name']} is now your primary contact.');
      _load();
    } on ApiException catch (e) {
      if (mounted) toast(context, e.message, error: true);
    }
  }

  Future<void> _delete(Map<String, dynamic> c) async {
    if (!await confirmDialog(context, title: 'Delete ${c['name']}?', body: 'They will no longer be listed on your alerts.', ok: 'Delete', danger: true)) return;
    try {
      await Api.I.deleteContact((c['id'] as num).toInt());
      if (mounted) toast(context, 'Contact deleted.');
      _load();
    } on ApiException catch (e) {
      if (mounted) toast(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = _list;
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(onPressed: () => _edit(), icon: const Icon(Icons.person_add), label: const Text('Add contact')),
      body: l == null
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 96), children: [
                if (l.isEmpty)
                  SectionCard(
                      child: EmptyState(
                          icon: Icons.people_outline,
                          title: 'No emergency contacts yet',
                          text: "Add someone you trust. They'll be listed on any SOS alert you raise.",
                          action: FilledButton(onPressed: () => _edit(), child: const Text('Add contact'))))
                else
                  ...l.map((c) => Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: SectionCard(
                          padding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
                          child: Row(children: [
                            CircleAvatar(backgroundColor: AppColors.soft,
                                child: Text((c['name'] as String).isEmpty ? '?' : (c['name'] as String)[0].toUpperCase(),
                                    style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800))),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Row(children: [
                                  Flexible(child: Text(c['name'] as String, style: const TextStyle(fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis)),
                                  if (c['primary'] == true) ...[const SizedBox(width: 6), const StatusChip('Primary')],
                                ]),
                                Text('${c['relationship']} · ${c['phone']}', style: const TextStyle(color: AppColors.grey)),
                              ]),
                            ),
                            IconButton(tooltip: 'Call', icon: const Icon(Icons.call, color: AppColors.ok), onPressed: () => launchUrl(Uri.parse('tel:${c['phone']}'))),
                            PopupMenuButton<String>(
                              tooltip: 'More',
                              onSelected: (v) => v == 'edit' ? _edit(c) : v == 'primary' ? _primary(c) : _delete(c),
                              itemBuilder: (_) => [
                                const PopupMenuItem(value: 'edit', child: Text('Edit')),
                                if (c['primary'] != true) const PopupMenuItem(value: 'primary', child: Text('Set as primary')),
                                const PopupMenuItem(value: 'delete', child: Text('Delete')),
                              ],
                            ),
                          ]),
                        ),
                      )),
              ]),
            ),
    );
  }
}
