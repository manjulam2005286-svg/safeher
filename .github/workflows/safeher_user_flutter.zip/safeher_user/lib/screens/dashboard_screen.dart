import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../services/live_location.dart';
import '../services/location.dart';
import '../services/sound.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/sos_button.dart';
import 'emergency_screen.dart';
import 'fake_call_screen.dart';
import 'location_picker.dart';

class DashboardScreen extends StatefulWidget {
  final void Function(int tab) onOpenTab;
  const DashboardScreen({super.key, required this.onOpenTab});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with WidgetsBindingObserver {
  List<Map<String, dynamic>> _contacts = [], _alerts = [];
  bool _loading = true, _sosBusy = false, _askOpen = false;
  String? _sosMsg;
  Timer? _tick;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
    _tick = Timer.periodic(const Duration(seconds: 1), (_) => _onTick());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _tick?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final r = await Future.wait([Api.I.contacts(), Api.I.alerts()]);
      if (!mounted) return;
      setState(() {
        _contacts = r[0];
        _alerts = r[1];
        _loading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      toast(context, e.message, error: true);
    }
  }

  Map<String, dynamic>? get _active {
    for (final a in _alerts) {
      if (isOpenStatus(a['status'] as String?)) return a;
    }
    return null;
  }

  // ---------------- SOS ----------------
  Future<void> _sos() async {
    setState(() {
      _sosBusy = true;
      _sosMsg = 'Capturing your location…';
    });
    try {
      final p = await currentPosition();
      final a = await Api.I.createAlert(p.latitude, p.longitude, p.accuracy);
      final id = (a['id'] as num).toInt();
      await LiveLocation.I.start(id);
      if (!mounted) return;
      setState(() => _sosMsg = null);
      await Navigator.push(context, MaterialPageRoute(builder: (_) => EmergencyScreen(alertId: id, askExact: isApprox(p.accuracy))));
      _load();
    } on LocationError catch (e) {
      setState(() => _sosMsg = e.message);
      if (e.openSettings) await Geolocator.openAppSettings();
    } on ApiException catch (e) {
      setState(() => _sosMsg = 'Unable to raise SOS. ${e.message}');
    } finally {
      if (mounted) setState(() => _sosBusy = false);
    }
  }

  // ---------------- Safe Check Timer ----------------
  int get _end => Api.I.prefs.getInt('timerEnd') ?? 0;
  int get _total => Api.I.prefs.getInt('timerTotal') ?? 1;
  bool get _running => _end > DateTime.now().millisecondsSinceEpoch;
  bool get _expired => _end != 0 && !_running;

  Future<void> _startTimer(double minutes) async {
    final ms = (minutes * 60000).round();
    await Api.I.prefs.setInt('timerEnd', DateTime.now().millisecondsSinceEpoch + ms);
    await Api.I.prefs.setInt('timerTotal', ms);
    await Api.I.prefs.setBool('timerUsed', true);
    if (mounted) toast(context, minutes < 1 ? 'Demo Safe Check started (6 seconds).' : 'Safe Check started for ${minutes.round()} minutes.');
    setState(() {});
  }

  Future<void> _clearTimer() async {
    await Api.I.prefs.remove('timerEnd');
    await Api.I.prefs.remove('timerTotal');
    setState(() {});
  }

  void _onTick() {
    if (!mounted) return;
    if (_expired && !_askOpen) _askSafe();
    if (_running) setState(() {});
  }

  Future<void> _askSafe() async {
    _askOpen = true;
    Sound.playBeep();
    HapticFeedback.vibrate();
    final sos = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (c) => AlertDialog(
        title: const Text('Are you safe?'),
        content: const Text('Your Safe Check time is up.'),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(c, false), child: const Text("I'm Safe")),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: AppColors.red), onPressed: () => Navigator.pop(c, true), child: const Text('Activate SOS')),
        ],
      ),
    );
    await _clearTimer();
    _askOpen = false;
    if (!mounted) return;
    if (sos == true) {
      _sos();
    } else {
      toast(context, 'Marked safe. Timer cleared.');
    }
  }

  String _fmtLeft(int ms) {
    final s = (ms / 1000).ceil();
    return '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';
  }

  // ---------------- Share location ----------------
  Future<void> _shareLocation() async {
    showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (_) => const _ShareLocationSheet());
  }

  // ---------------- UI ----------------
  int get _setupPct {
    final u = Api.I.user ?? {};
    var done = 0;
    if ((u['name'] ?? '').toString().isNotEmpty && (u['phone'] ?? '').toString().isNotEmpty) done++;
    if (_contacts.isNotEmpty) done++;
    if (_contacts.any((c) => c['primary'] == true)) done++;
    if (Api.I.prefs.getBool('timerUsed') ?? false) done++;
    return (done / 4 * 100).round();
  }

  @override
  Widget build(BuildContext context) {
    final h = DateTime.now().hour;
    final first = (Api.I.user?['name'] as String? ?? '').split(' ').first;
    final active = _active;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        // Greeting
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), gradient: const LinearGradient(colors: [AppColors.primary, AppColors.violet])),
          child: Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'}, $first',
                    style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(
                    _loading
                        ? 'Loading your safety status…'
                        : active != null
                            ? '⚠ Emergency alert #${active['id']} is active'
                            : _running
                                ? 'Safe Check is running'
                                : '✓ All clear. No active emergency.',
                    style: const TextStyle(color: Colors.white70)),
              ]),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(20)),
              child: Text(_setupPct == 100 ? '✓ Ready' : 'Setup $_setupPct%', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
            ),
          ]),
        ),
        if (active != null) ...[
          const SizedBox(height: 12),
          SectionCard(
            color: const Color(0xFFFFE4EA),
            borderColor: AppColors.red,
            child: Row(children: [
              Expanded(child: Text('🚨 Emergency #${active['id']} is ${active['status']}', style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF9F1239)))),
              FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: AppColors.red),
                  onPressed: () async {
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => EmergencyScreen(alertId: (active['id'] as num).toInt())));
                    _load();
                  },
                  child: const Text('Open')),
            ]),
          ),
        ],
        const SizedBox(height: 16),
        // SOS
        SectionCard(
          child: Column(children: [
            const Text('EMERGENCY SOS', style: TextStyle(color: AppColors.red, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
            const SizedBox(height: 10),
            SosButton(onTriggered: _sos, busy: _sosBusy),
            const SizedBox(height: 10),
            const Text('Press & hold for 3 seconds', style: TextStyle(fontWeight: FontWeight.w700)),
            if (_sosMsg != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_sosMsg!, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.red))),
            const SizedBox(height: 8),
            const Text('Creates an emergency alert with your live location for the response desk. Contact notifications are simulated in this demo.',
                textAlign: TextAlign.center, style: TextStyle(color: AppColors.grey, fontSize: 12)),
          ]),
        ),
        const SizedBox(height: 20),
        const Text('Quick Actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.5,
          children: [
            _action(Icons.my_location, 'Share My Location', 'Send your coordinates', _shareLocation),
            _action(Icons.call, 'Fake Call', 'Simulated incoming call', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FakeCallScreen()))),
            _action(Icons.shield_outlined, 'Safety Center', 'Status, setup & tips', () => widget.onOpenTab(1)),
            _action(Icons.local_phone, 'Call 112', 'National emergency number', () => launchUrl(Uri.parse('tel:112'))),
          ],
        ),
        const SizedBox(height: 20),
        _timerCard(),
        const SizedBox(height: 16),
        SectionCard(
          title: 'Recent Alerts',
          trailing: TextButton(onPressed: () => widget.onOpenTab(3), child: const Text('View all')),
          child: _alerts.isEmpty
              ? const EmptyState(icon: Icons.verified_user_outlined, title: 'No emergency alerts', text: "That's a good thing. Alerts you raise with SOS appear here.")
              : Column(
                  children: _alerts.take(3).map((a) => ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text('Alert #${a['id']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text(fmtDateTime(a['createdAt'] as String)),
                        trailing: StatusChip(a['status'] as String),
                        onTap: () async {
                          await Navigator.push(context, MaterialPageRoute(builder: (_) => EmergencyScreen(alertId: (a['id'] as num).toInt())));
                          _load();
                        },
                      )).toList()),
        ),
        const SizedBox(height: 24),
      ]),
    );
  }

  Widget _action(IconData icon, String title, String text, VoidCallback onTap) => Material(
        color: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: AppColors.line)),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              CircleAvatar(radius: 18, backgroundColor: AppColors.soft, child: Icon(icon, color: AppColors.primary, size: 20)),
              const SizedBox(height: 8),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
              Text(text, style: const TextStyle(color: AppColors.grey, fontSize: 12), maxLines: 1, overflow: TextOverflow.ellipsis),
            ]),
          ),
        ),
      );

  Widget _timerCard() {
    final running = _running;
    final left = _end - DateTime.now().millisecondsSinceEpoch;
    return SectionCard(
      title: '⏱ Safe Check Timer',
      trailing: StatusChip(running ? 'Active' : 'Ready'),
      child: running
          ? Column(children: [
              Text(_fmtLeft(left), style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800, fontFeatures: [FontFeature.tabularFigures()])),
              const SizedBox(height: 6),
              LinearProgressIndicator(value: (left / _total).clamp(0.0, 1.0), minHeight: 8, borderRadius: BorderRadius.circular(8)),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: FilledButton(onPressed: () async {
                  await _clearTimer();
                  if (mounted) toast(context, 'Marked safe. Timer cleared.');
                }, child: const Text("I'm Safe"))),
                const SizedBox(width: 10),
                Expanded(child: OutlinedButton(onPressed: () async {
                  if (await confirmDialog(context, title: 'Cancel Safe Check?', body: "You won't be asked whether you arrived safely.", ok: 'Cancel timer', cancel: 'Keep running')) {
                    await _clearTimer();
                  }
                }, child: const Text('Cancel'))),
              ]),
              const SizedBox(height: 6),
              const Text('Keep SafeHer open so it can ask you when the time is up.', style: TextStyle(color: AppColors.grey, fontSize: 12)),
            ])
          : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text("Travelling somewhere? Pick when you expect to arrive. If you haven't confirmed you're safe by then, SafeHer asks and lets you raise SOS.",
                  style: TextStyle(color: AppColors.grey)),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final m in [10, 20, 30, 60]) OutlinedButton(onPressed: () => _startTimer(m.toDouble()), child: Text('$m min')),
                FilledButton(onPressed: () => _startTimer(0.1), child: const Text('Demo (6 s)')),
              ]),
            ]),
    );
  }
}

class _ShareLocationSheet extends StatefulWidget {
  const _ShareLocationSheet();
  @override
  State<_ShareLocationSheet> createState() => _ShareLocationSheetState();
}

class _ShareLocationSheetState extends State<_ShareLocationSheet> {
  double? _lat, _lng, _acc;
  String? _label, _err;

  @override
  void initState() {
    super.initState();
    _get();
  }

  Future<void> _get() async {
    setState(() => _err = null);
    try {
      final p = await currentPosition();
      setState(() {
        _lat = p.latitude;
        _lng = p.longitude;
        _acc = p.accuracy;
        _label = null;
      });
    } on LocationError catch (e) {
      setState(() => _err = e.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    final has = _lat != null;
    final coords = has ? '${_lat!.toStringAsFixed(6)}, ${_lng!.toStringAsFixed(6)}' : '';
    final map = 'https://www.google.com/maps?q=$_lat,$_lng';
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 24 + MediaQuery.of(context).viewInsets.bottom),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('📍 My Location', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        if (_err != null) ...[
          Text(_err!, style: const TextStyle(color: AppColors.red)),
          const SizedBox(height: 8),
          Wrap(spacing: 8, children: [
            OutlinedButton(onPressed: _get, child: const Text('Try again')),
            FilledButton(
                onPressed: () async {
                  final p = await Navigator.push<PickedLocation>(context, MaterialPageRoute(builder: (_) => const LocationPickerScreen()));
                  if (p != null) setState(() { _lat = p.lat; _lng = p.lng; _label = p.label; _acc = null; _err = null; });
                },
                child: const Text('Set location manually')),
          ]),
        ] else if (!has)
          const Padding(padding: EdgeInsets.all(12), child: Center(child: CircularProgressIndicator()))
        else ...[
          SelectableText(coords, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
          Text(_label != null ? '📌 Exact location you set: $_label' : 'Accuracy ${accuracyText(_acc!)}', style: const TextStyle(color: AppColors.grey)),
          if (_label == null && isApprox(_acc))
            WarnBox('⚠ Approximate location (${accuracyText(_acc!)}). This device could only estimate your position. Set your exact location for accuracy.'),
          const SizedBox(height: 12),
          Wrap(spacing: 8, runSpacing: 8, children: [
            OutlinedButton.icon(
                icon: const Icon(Icons.copy, size: 18),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: coords));
                  toast(context, 'Coordinates copied.');
                },
                label: const Text('Copy')),
            OutlinedButton.icon(icon: const Icon(Icons.map, size: 18), onPressed: () => launchUrl(Uri.parse(map), mode: LaunchMode.externalApplication), label: const Text('Google Maps')),
            OutlinedButton.icon(
                icon: const Icon(Icons.share, size: 18),
                onPressed: () => launchUrl(Uri.parse('https://wa.me/?text=${Uri.encodeComponent('My current location: $map')}'), mode: LaunchMode.externalApplication),
                label: const Text('WhatsApp')),
            FilledButton.icon(
                icon: const Icon(Icons.push_pin, size: 18),
                onPressed: () async {
                  final p = await Navigator.push<PickedLocation>(
                      context, MaterialPageRoute(builder: (_) => LocationPickerScreen(start: (lat: _lat!, lng: _lng!))));
                  if (p != null) setState(() { _lat = p.lat; _lng = p.lng; _label = p.label; _acc = null; });
                },
                label: Text(_label == null ? 'Set exact location' : 'Change')),
          ]),
        ],
      ]),
    );
  }
}
