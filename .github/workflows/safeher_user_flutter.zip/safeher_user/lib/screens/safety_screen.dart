import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../services/live_location.dart';
import '../services/location.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'emergency_screen.dart';

const _tips = [
  ['Travel Safety', 'Share your route and expected arrival time with someone you trust before longer trips.'],
  ['Travel Safety', 'Before getting into a cab, check that the vehicle number and driver match the booking app.'],
  ['Night Travel', 'Prefer well-lit, busy routes and keep your phone charged before heading out at night.'],
  ['Night Travel', 'On late buses or trains, sit near the driver or other passengers when you can.'],
  ['Public Place Safety', 'When you arrive somewhere new, note the exits and where staff or security are.'],
  ['Public Place Safety', 'If someone makes you uncomfortable, move toward staff, security or a group of people.'],
  ['Digital Safety', 'Review which apps can see your location and turn off sharing you no longer need.'],
  ['Digital Safety', 'Avoid posting your live location publicly. Share where you were after you have left.'],
  ['Emergency Preparedness', 'Save at least two emergency contacts and mark the one most likely to answer as primary.'],
  ['Emergency Preparedness', 'Know your local emergency number. In India, 112 connects to police, fire and ambulance.'],
];

class SafetyScreen extends StatefulWidget {
  const SafetyScreen({super.key});
  @override
  State<SafetyScreen> createState() => _SafetyScreenState();
}

class _SafetyScreenState extends State<SafetyScreen> {
  List<Map<String, dynamic>> _alerts = [], _contacts = [];
  bool _loc = false, _loaded = false;
  int _tip = DateTime.now().difference(DateTime(DateTime.now().year)).inDays % _tips.length;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await Future.wait([Api.I.alerts(), Api.I.contacts()]);
      final loc = await hasLocationPermission();
      if (!mounted) return;
      setState(() {
        _alerts = r[0];
        _contacts = r[1];
        _loc = loc;
        _loaded = true;
      });
    } on ApiException catch (e) {
      if (mounted) toast(context, e.message, error: true);
    }
  }

  Map<String, dynamic>? get _active {
    for (final a in _alerts) {
      if (isOpenStatus(a['status'] as String?)) return a;
    }
    return null;
  }

  Future<void> _close(Map<String, dynamic> a, String status) async {
    final cancel = status == 'Cancelled';
    if (!await confirmDialog(context,
        title: cancel ? 'Cancel this emergency?' : 'Mark yourself safe?', ok: cancel ? 'Cancel emergency' : 'Mark safe', cancel: 'Keep active', danger: cancel)) return;
    try {
      await Api.I.setStatus((a['id'] as num).toInt(), status);
      if (LiveLocation.I.alertId == a['id']) await LiveLocation.I.stop();
      if (mounted) toast(context, cancel ? 'Emergency cancelled.' : 'Marked safe. Emergency resolved.');
      _load();
    } on ApiException catch (e) {
      if (mounted) toast(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final u = Api.I.user ?? {};
    final items = <(String, bool, VoidCallback?)>[
      ('Profile completed', (u['name'] ?? '').toString().isNotEmpty && (u['phone'] ?? '').toString().isNotEmpty, null),
      ('Emergency contact added', _contacts.isNotEmpty, null),
      ('Primary contact selected', _contacts.any((c) => c['primary'] == true), null),
      ('Location permission enabled', _loc, () async {
        try {
          await ensureLocationPermission();
        } on LocationError catch (e) {
          if (mounted) toast(context, e.message, error: true);
        }
        _load();
      }),
      ('Safe Check configured', Api.I.prefs.getBool('timerUsed') ?? false, null),
    ];
    final done = items.where((i) => i.$2).length, pct = (done / items.length * 100).round();
    final a = _active;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        // Emergency Center
        if (!_loaded)
          const SectionCard(child: Text('Checking emergency status…'))
        else if (a == null)
          SectionCard(
            title: 'Emergency Center',
            trailing: const StatusChip('Resolved'),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Everything is clear.', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              SizedBox(height: 4),
              Text('You have no active emergency alerts. If you ever need help, hold the SOS button on Home for 3 seconds.', style: TextStyle(color: AppColors.grey)),
            ]),
          )
        else
          SectionCard(
            title: '🚨 Emergency Active',
            trailing: StatusChip(a['status'] as String),
            color: const Color(0xFFFFF8F9),
            borderColor: AppColors.red,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _kv('Emergency ID', '#${a['id']}'),
              _kv('Activated at', fmtDateTime(a['createdAt'] as String)),
              _kv('Location', '${(a['lat'] as num).toStringAsFixed(5)}, ${(a['lng'] as num).toStringAsFixed(5)}'),
              _kv('Contacts on file', '${(a['contacts'] as List).length} (demo notification)'),
              _kv('Response', a['status'] == 'Responded' ? 'Response desk has responded' : 'Waiting for response desk'),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 8, children: [
                FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => EmergencyScreen(alertId: (a['id'] as num).toInt()))),
                    child: const Text('Open')),
                OutlinedButton(onPressed: () => _close(a, 'Resolved'), child: const Text('Mark Safe')),
                FilledButton(style: FilledButton.styleFrom(backgroundColor: AppColors.red), onPressed: () => _close(a, 'Cancelled'), child: const Text('Cancel')),
              ]),
            ]),
          ),
        const SizedBox(height: 16),
        // Setup checklist
        SectionCard(
          title: 'Complete Your Safety Setup',
          trailing: StatusChip(pct == 100 ? 'Ready' : '$pct%'),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            ...items.map((i) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  leading: Icon(i.$2 ? Icons.check_circle : Icons.radio_button_unchecked, color: i.$2 ? AppColors.ok : AppColors.grey),
                  title: Text(i.$1),
                  trailing: i.$2
                      ? const Text('Done', style: TextStyle(color: AppColors.ok, fontWeight: FontWeight.w700))
                      : i.$3 != null
                          ? TextButton(onPressed: i.$3, child: const Text('Enable'))
                          : const Text('Pending', style: TextStyle(color: AppColors.grey)),
                )),
            const SizedBox(height: 8),
            LinearProgressIndicator(value: pct / 100, minHeight: 8, borderRadius: BorderRadius.circular(8)),
            const SizedBox(height: 8),
            pct == 100
                ? const WarnBox("✓ You're Ready. Safety Setup 100% complete.", good: true)
                : Text('Safety Setup $pct% complete', style: const TextStyle(fontWeight: FontWeight.w700)),
            const Text('Setup readiness indicator only, not a real-world safety score.', style: TextStyle(color: AppColors.grey, fontSize: 12)),
          ]),
        ),
        const SizedBox(height: 16),
        // Tip
        SectionCard(
          title: '💡 Daily Safety Tip',
          trailing: StatusChip(_tips[_tip][0]),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_tips[_tip][1], style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 10),
            Row(children: [
              OutlinedButton(onPressed: () => setState(() => _tip = (_tip + 1) % _tips.length), child: const Text('Next Tip')),
              const SizedBox(width: 10),
              Text('Tip ${_tip + 1} of ${_tips.length}', style: const TextStyle(color: AppColors.grey)),
            ]),
          ]),
        ),
        const SizedBox(height: 20),
        const Text('Emergency Preparation', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        _prep('🎒 Before Travelling', ['Keep your phone charged', 'Keep emergency contacts updated', 'Turn on location', 'Plan your route']),
        _prep('🚶‍♀️ During Travel', ['Stay aware of your surroundings', 'Run a Safe Check Timer', 'Check in with someone when needed']),
        _prep('🆘 In an Emergency', ['Move to a safer public location', 'Contact people you trust', 'Use SOS when necessary', 'Call 112 for police, fire or ambulance']),
        const SizedBox(height: 8),
        SectionCard(
          title: 'In immediate danger?',
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text("Call 112 (India's national emergency number). SafeHer does not replace official emergency services.", style: TextStyle(color: AppColors.grey)),
            const SizedBox(height: 10),
            FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: AppColors.red),
                onPressed: () => launchUrl(Uri.parse('tel:112')),
                icon: const Icon(Icons.local_phone),
                label: const Text('Call 112')),
          ]),
        ),
        const SizedBox(height: 24),
      ]),
    );
  }

  Widget _kv(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 130, child: Text(k, style: const TextStyle(color: AppColors.grey))),
          Expanded(child: Text(v, style: const TextStyle(fontWeight: FontWeight.w600))),
        ]),
      );

  Widget _prep(String title, List<String> items) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: SectionCard(
          title: title,
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: items
                  .map((t) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: Row(children: [const Text('•  '), Expanded(child: Text(t, style: const TextStyle(color: AppColors.grey)))])))
                  .toList()),
        ),
      );
}
