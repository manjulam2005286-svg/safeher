import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../services/live_location.dart';
import '../services/location.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'location_picker.dart';

class EmergencyScreen extends StatefulWidget {
  final int alertId;
  final bool askExact;
  const EmergencyScreen({super.key, required this.alertId, this.askExact = false});
  @override
  State<EmergencyScreen> createState() => _EmergencyScreenState();
}

class _EmergencyScreenState extends State<EmergencyScreen> {
  Map<String, dynamic>? _a;
  Timer? _poll, _tick;
  bool _offline = false, _asked = false;
  static const _steps = ['User Triggered SOS', 'Location Captured', 'Emergency Alert Created', 'Emergency Contacts Notified (Demo)', 'Emergency Response Active'];

  @override
  void initState() {
    super.initState();
    _load();
    _poll = Timer.periodic(const Duration(seconds: 4), (_) => _load());
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _poll?.cancel();
    _tick?.cancel();
    super.dispose(); // live sharing keeps running in the background service
  }

  bool get _open => isOpenStatus(_a?['status'] as String?);
  bool get _manual => _a?['locationSource'] == 'manual';

  Future<void> _load() async {
    try {
      final a = await Api.I.alert(widget.alertId);
      if (!mounted) return;
      if (_offline) toast(context, 'Reconnected to SafeHer.');
      setState(() {
        _a = a;
        _offline = false;
      });
      if (_open) {
        LiveLocation.I.start(widget.alertId, manualPin: _manual);
      } else if (LiveLocation.I.alertId == widget.alertId) {
        LiveLocation.I.stop();
      }
      // Rough location (laptop / no GPS fix): ask once for the exact location. The alert is already sent.
      if (widget.askExact && !_asked && _open && !_manual && isApprox(a['accuracy'] as num?)) {
        _asked = true;
        _setExact(auto: true);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      if (!_offline) toast(context, e.message, error: true);
      setState(() => _offline = true);
    }
  }

  Future<void> _setExact({bool auto = false}) async {
    final a = _a;
    final p = await Navigator.push<PickedLocation>(
        context,
        MaterialPageRoute(
            builder: (_) => LocationPickerScreen(
                  title: auto ? 'SOS sent. Where exactly are you?' : 'Set your exact location',
                  intro: auto ? 'Your alert is sent, but your location is only approximate. Search a nearby place, paste a Google Maps link or tap the map so help can find you.' : null,
                  start: a == null ? null : (lat: (a['lat'] as num).toDouble(), lng: (a['lng'] as num).toDouble()),
                )));
    if (p == null) return;
    try {
      await Api.I.updateLocation(widget.alertId, p.lat, p.lng, source: 'manual', label: p.label);
      LiveLocation.I.markManual(p.lat, p.lng);
      if (mounted) toast(context, 'Exact location shared with the response desk.');
      _load();
    } on ApiException catch (e) {
      if (mounted) toast(context, 'Could not update location. ${e.message}', error: true);
    }
  }

  Future<void> _close(String status) async {
    final cancel = status == 'Cancelled';
    if (!await confirmDialog(context,
        title: cancel ? 'Cancel this emergency?' : 'Mark yourself safe?',
        body: cancel ? 'The response desk will see that you cancelled the alert.' : 'This closes the alert as resolved.',
        ok: cancel ? 'Cancel emergency' : 'Mark safe',
        cancel: 'Keep active',
        danger: cancel)) return;
    try {
      await Api.I.setStatus(widget.alertId, status);
      await LiveLocation.I.stop();
      if (mounted) toast(context, cancel ? 'Emergency cancelled.' : 'Marked safe. Emergency resolved.');
      _load();
    } on ApiException catch (e) {
      if (mounted) toast(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final a = _a;
    if (a == null) {
      return Scaffold(appBar: AppBar(title: const Text('Emergency')), body: const Center(child: CircularProgressIndicator()));
    }
    final status = a['status'] as String;
    final lat = (a['lat'] as num).toDouble(), lng = (a['lng'] as num).toDouble();
    final n = status == 'Pending' ? 4 : status == 'Cancelled' ? 3 : 5;
    final title = status == 'Resolved' ? 'Emergency Resolved' : status == 'Cancelled' ? 'Emergency Cancelled' : 'Emergency Active';
    final contacts = List<Map<String, dynamic>>.from(a['contacts'] as List? ?? []);
    return Scaffold(
      appBar: AppBar(title: Text('Alert #${a['id']}')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: _open ? AppColors.red : AppColors.grey, borderRadius: BorderRadius.circular(20)),
          child: Row(children: [
            Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('SOS ALERT', style: TextStyle(color: Colors.white70, fontSize: 12, letterSpacing: 1)),
              Text(title, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
              Text(fmtDateTime(a['createdAt'] as String), style: const TextStyle(color: Colors.white70)),
            ])),
            StatusChip(status),
          ]),
        ),
        const SizedBox(height: 16),
        SectionCard(
          title: 'Response timeline',
          child: Column(children: [
            for (var i = 0; i < _steps.length; i++) _step(_steps[i], i < n),
            if (status == 'Resolved') _step('Emergency Resolved', true),
            if (status == 'Cancelled') _step('Cancelled by user', true),
          ]),
        ),
        const SizedBox(height: 16),
        ListenableBuilder(listenable: LiveLocation.I, builder: (context, _) => _locationCard(a, lat, lng)),
        const SizedBox(height: 16),
        SectionCard(
          title: '👥 Emergency contacts',
          trailing: const StatusChip('Demo notification'),
          child: Column(
              children: contacts
                  .map((c) => ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text('${c['name']}${c['primary'] == true ? ' · Primary' : ''}'),
                        subtitle: Text('${c['relationship']} · ${c['phone']}'),
                        trailing: IconButton(tooltip: 'Call ${c['name']}', icon: const Icon(Icons.call, color: AppColors.ok),
                            onPressed: () => launchUrl(Uri.parse('tel:${c['phone']}'))),
                      ))
                  .toList()),
        ),
        const SizedBox(height: 16),
        if (_open) ...[
          FilledButton.icon(onPressed: () => _close('Resolved'), icon: const Icon(Icons.verified_user), label: const Text("I'm Safe – Mark resolved")),
          const SizedBox(height: 10),
          FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: AppColors.red),
              onPressed: () => _close('Cancelled'),
              icon: const Icon(Icons.cancel),
              label: const Text('Cancel Emergency')),
        ] else
          WarnBox(status == 'Cancelled' ? 'You cancelled this alert. The response team has been informed.' : 'This alert was marked resolved.', good: status == 'Resolved'),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: () => launchUrl(Uri.parse('tel:112')), icon: const Icon(Icons.local_phone), label: const Text('Call 112')),
        const SizedBox(height: 24),
      ]),
    );
  }

  Widget _step(String t, bool done) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(children: [
          Icon(done ? Icons.check_circle : Icons.radio_button_unchecked, color: done ? AppColors.ok : AppColors.line),
          const SizedBox(width: 10),
          Expanded(child: Text(t, style: TextStyle(fontWeight: done ? FontWeight.w600 : FontWeight.w400, color: done ? AppColors.ink : AppColors.grey))),
        ]),
      );

  Widget _locationCard(Map<String, dynamic> a, double lat, double lng) {
    final live = LiveLocation.I;
    final acc = a['accuracy'] as num?;
    final mine = live.alertId == widget.alertId;
    String tag;
    if (!_open) {
      tag = 'Sharing stopped';
    } else if (_manual) {
      tag = '📌 Exact location set';
    } else if (mine && live.error != null) {
      tag = '⚠ Live paused';
    } else {
      tag = '● LIVE';
    }
    return SectionCard(
      title: '📍 Live location',
      trailing: StatusChip(tag),
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: SizedBox(
            height: 200,
            child: FlutterMap(
              key: ValueKey('$lat,$lng'),
              options: MapOptions(initialCenter: LatLng(lat, lng), initialZoom: 16),
              children: [
                TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.safeher.safeher_user'),
                MarkerLayer(markers: [
                  Marker(point: LatLng(lat, lng), width: 44, height: 44, alignment: Alignment.topCenter,
                      child: const Icon(Icons.location_pin, color: AppColors.red, size: 44)),
                ]),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Text('${lat.toStringAsFixed(6)}, ${lng.toStringAsFixed(6)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        Text('Updated ${agoText(a['locationUpdatedAt'] as String?)}', style: const TextStyle(color: AppColors.grey, fontSize: 12)),
        if (_open && !_manual && isApprox(acc))
          WarnBox('⚠ Approximate location (${accuracyText(acc!)}). Your device has no precise GPS fix. Set your exact location so help can find you.'),
        if (_manual) WarnBox('📌 Exact location set by you: ${a['locationLabel']}', good: true),
        if (_open)
          Text(
              _manual
                  ? 'The response desk sees the location you set. A precise GPS fix will replace it automatically.'
                  : mine && live.error != null
                      ? live.error!
                      : '${live.lastSent != null ? 'Last sent ${DateTime.now().difference(live.lastSent!).inSeconds}s ago. ' : ''}Your live location is shared with the response desk, even when SafeHer is minimised.',
              style: const TextStyle(color: AppColors.grey, fontSize: 13)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          OutlinedButton.icon(
              icon: const Icon(Icons.map, size: 18),
              onPressed: () => launchUrl(Uri.parse('https://www.google.com/maps?q=$lat,$lng'), mode: LaunchMode.externalApplication),
              label: const Text('Open in Maps')),
          if (_open)
            FilledButton.icon(
                icon: const Icon(Icons.push_pin, size: 18), onPressed: () => _setExact(), label: Text(_manual ? 'Change location' : 'Set exact location')),
        ]),
      ]),
    );
  }
}
