import 'package:flutter/material.dart';
import '../api.dart';
import '../services/live_location.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'contacts_screen.dart';
import 'dashboard_screen.dart';
import 'emergency_screen.dart';
import 'history_screen.dart';
import 'login_screen.dart';
import 'safety_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;
  final _titles = const ['SafeHer', 'Safety Center', 'Emergency Contacts', 'Alert History'];

  Future<void> _logout() async {
    if (!await confirmDialog(context, title: 'Log out?', body: 'Live location sharing will stop.', ok: 'Log out')) return;
    await LiveLocation.I.stop();
    await Api.I.logout();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardScreen(onOpenTab: (i) => setState(() => _tab = i)),
      const SafetyScreen(),
      const ContactsScreen(),
      const HistoryScreen(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_tab], style: const TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'Account',
            icon: CircleAvatar(
                backgroundColor: AppColors.soft,
                child: Text((Api.I.user?['name'] as String? ?? '?').trim().isEmpty ? '?' : (Api.I.user!['name'] as String).trim()[0].toUpperCase(),
                    style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800))),
            onSelected: (v) => v == 'logout' ? _logout() : null,
            itemBuilder: (_) => [
              PopupMenuItem(enabled: false, child: Text('${Api.I.user?['name'] ?? ''}\n${Api.I.user?['email'] ?? ''}')),
              const PopupMenuItem(value: 'logout', child: Text('Log out')),
            ],
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(children: [
        // Shown on every tab while live location is being shared
        ListenableBuilder(
          listenable: LiveLocation.I,
          builder: (context, _) => LiveLocation.I.active
              ? Material(
                  color: AppColors.red,
                  child: InkWell(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => EmergencyScreen(alertId: LiveLocation.I.alertId!))),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      child: Row(children: [
                        const Icon(Icons.sensors, color: Colors.white),
                        const SizedBox(width: 10),
                        Expanded(
                            child: Text('SOS #${LiveLocation.I.alertId} active · sharing live location',
                                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
                        const Icon(Icons.chevron_right, color: Colors.white),
                      ]),
                    ),
                  ),
                )
              : const SizedBox.shrink(),
        ),
        Expanded(child: IndexedStack(index: _tab, children: pages)),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.shield_outlined), selectedIcon: Icon(Icons.shield), label: 'Safety'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Contacts'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
        ],
      ),
    );
  }
}
