import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiException implements Exception {
  final String message;
  final int status;
  ApiException(this.message, [this.status = 0]);
  @override
  String toString() => message;
}

/// Talks to the existing SafeHer Node.js/Express backend (same REST API as the web app).
class Api {
  Api._();
  static final Api I = Api._();

  late SharedPreferences prefs;
  String baseUrl = '';
  String? token;
  Map<String, dynamic>? user;

  /// Called when the server says the session is no longer valid (e.g. server restarted).
  void Function()? onSessionExpired;

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    baseUrl = prefs.getString('server') ?? 'http://192.168.1.10:5050';
    token = prefs.getString('token');
    final u = prefs.getString('user');
    if (u != null) user = jsonDecode(u) as Map<String, dynamic>;
  }

  bool get loggedIn => token != null && user != null;
  int get userId => (user!['id'] as num).toInt();

  Future<void> setServer(String url) async {
    var u = url.trim().replaceAll(RegExp(r'/+$'), '');
    if (u.isNotEmpty && !u.startsWith('http')) u = 'http://$u';
    baseUrl = u;
    await prefs.setString('server', baseUrl);
  }

  Future<dynamic> _req(String method, String path, [Object? body]) async {
    final uri = Uri.parse('$baseUrl/api$path');
    final headers = {'Content-Type': 'application/json', if (token != null) 'Authorization': token!};
    final b = body == null ? null : jsonEncode(body);
    http.Response r;
    try {
      final Future<http.Response> f = switch (method) {
        'POST' => http.post(uri, headers: headers, body: b),
        'PUT' => http.put(uri, headers: headers, body: b),
        'DELETE' => http.delete(uri, headers: headers),
        _ => http.get(uri, headers: headers),
      };
      r = await f.timeout(const Duration(seconds: 15));
    } catch (_) {
      throw ApiException("Can't reach the SafeHer server at $baseUrl. Check Wi-Fi and the server address.");
    }
    dynamic d;
    try {
      d = r.body.isEmpty ? null : jsonDecode(r.body);
    } catch (_) {
      d = null;
    }
    if (r.statusCode == 401 && !path.startsWith('/auth/')) {
      await logout();
      onSessionExpired?.call();
      throw ApiException('Session expired. Please log in again.', 401);
    }
    if (r.statusCode >= 400) {
      throw ApiException(d is Map && d['error'] != null ? d['error'].toString() : 'Error ${r.statusCode}', r.statusCode);
    }
    return d;
  }

  Future<void> _save(Map<String, dynamic> d) async {
    token = d['token'] as String;
    user = Map<String, dynamic>.from(d['user'] as Map);
    await prefs.setString('token', token!);
    await prefs.setString('user', jsonEncode(user));
  }

  Future<void> login(String email, String password) async =>
      _save(Map<String, dynamic>.from(await _req('POST', '/auth/login', {'email': email, 'password': password}) as Map));

  Future<void> register(Map<String, dynamic> data) async =>
      _save(Map<String, dynamic>.from(await _req('POST', '/auth/register', data) as Map));

  Future<void> logout() async {
    token = null;
    user = null;
    await prefs.remove('token');
    await prefs.remove('user');
    await prefs.remove('timerEnd');
    await prefs.remove('timerTotal');
  }

  // ---- Contacts ----
  Future<List<Map<String, dynamic>>> contacts() async =>
      List<Map<String, dynamic>>.from(await _req('GET', '/contacts/$userId') as List);
  Future<void> addContact(Map<String, dynamic> c) => _req('POST', '/contacts', c);
  Future<void> updateContact(int id, Map<String, dynamic> c) => _req('PUT', '/contacts/$id', c);
  Future<void> deleteContact(int id) => _req('DELETE', '/contacts/$id');

  // ---- Emergency alerts ----
  Future<List<Map<String, dynamic>>> alerts() async =>
      List<Map<String, dynamic>>.from(await _req('GET', '/emergency/$userId') as List);
  Future<Map<String, dynamic>> alert(int id) async =>
      Map<String, dynamic>.from(await _req('GET', '/emergency/detail/$id') as Map);
  Future<Map<String, dynamic>> createAlert(double lat, double lng, double accuracy) async =>
      Map<String, dynamic>.from(await _req('POST', '/emergency/create', {'lat': lat, 'lng': lng, 'accuracy': accuracy}) as Map);
  Future<void> setStatus(int id, String status) => _req('PUT', '/emergency/$id/status', {'status': status});
  Future<void> updateLocation(int id, double lat, double lng, {double? accuracy, String? source, String? label}) =>
      _req('PUT', '/emergency/$id/location', {
        'lat': lat,
        'lng': lng,
        if (accuracy != null) 'accuracy': accuracy,
        if (source != null) 'source': source,
        if (label != null) 'label': label,
      });
}

bool isOpenStatus(String? s) => s == 'Pending' || s == 'Responded';
