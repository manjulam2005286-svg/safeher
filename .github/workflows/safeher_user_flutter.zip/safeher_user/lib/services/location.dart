import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';

class LocationError implements Exception {
  final String message;
  final bool openSettings;
  LocationError(this.message, {this.openSettings = false});
  @override
  String toString() => message;
}

/// Makes sure location services are on and permission is granted. Throws [LocationError] otherwise.
Future<void> ensureLocationPermission() async {
  if (!await Geolocator.isLocationServiceEnabled()) {
    throw LocationError('Location (GPS) is turned off. Please turn it on and try again.');
  }
  var p = await Geolocator.checkPermission();
  if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
  if (p == LocationPermission.denied) throw LocationError('Location permission was denied. SafeHer needs it to send your location.');
  if (p == LocationPermission.deniedForever) {
    throw LocationError('Location permission is blocked. Open app settings and allow location for SafeHer.', openSettings: true);
  }
}

Future<bool> hasLocationPermission() async {
  final p = await Geolocator.checkPermission();
  return p == LocationPermission.always || p == LocationPermission.whileInUse;
}

Future<Position> currentPosition() async {
  await ensureLocationPermission();
  try {
    return await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 15)));
  } catch (_) {
    final last = await Geolocator.getLastKnownPosition();
    if (last != null) return last;
    throw LocationError('Could not get your location. Move to an open area and try again.');
  }
}

/// Settings for continuous tracking. On Android a foreground service keeps sending
/// location even when the app is minimised or the screen is locked.
LocationSettings trackingSettings() {
  if (defaultTargetPlatform == TargetPlatform.android) {
    return AndroidSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 5,
      intervalDuration: const Duration(seconds: 5),
      foregroundNotificationConfig: const ForegroundNotificationConfig(
        notificationTitle: 'SafeHer SOS is active',
        notificationText: 'Sharing your live location with the response desk',
        enableWakeLock: true,
        setOngoing: true,
      ),
    );
  }
  if (defaultTargetPlatform == TargetPlatform.iOS) {
    return AppleSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 5,
      pauseLocationUpdatesAutomatically: false,
      allowBackgroundLocationUpdates: false, // set true only after adding UIBackgroundModes=location
    );
  }
  return const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 5);
}

/// Haversine distance in metres.
double distanceM(double lat1, double lng1, double lat2, double lng2) {
  const r = 6371000.0, d = math.pi / 180;
  final dLat = (lat2 - lat1) * d, dLng = (lng2 - lng1) * d;
  final h = math.pow(math.sin(dLat / 2), 2) + math.cos(lat1 * d) * math.cos(lat2 * d) * math.pow(math.sin(dLng / 2), 2);
  return 2 * r * math.asin(math.sqrt(h));
}

bool isApprox(num? accuracy) => accuracy != null && accuracy > 500;

String accuracyText(num accuracy) =>
    accuracy >= 1000 ? '±${(accuracy / 1000).toStringAsFixed(1)} km' : '±${accuracy.round()} m';

/// Reads coordinates from "10.99, 76.95" or a Google Maps link (…!3dLAT!4dLNG…, ?q=LAT,LNG, /@LAT,LNG,…).
({double lat, double lng})? parseCoords(String input) {
  var t = input;
  try {
    t = Uri.decodeFull(input);
  } catch (_) {}
  final patterns = [
    RegExp(r'!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)'),
    RegExp(r'[?&](?:q|query|ll|destination)=(-?\d+\.\d+)\s*,\s*(-?\d+\.\d+)'),
    RegExp(r'@(-?\d+\.\d+),\s*(-?\d+\.\d+)'),
    RegExp(r'^\s*(-?\d{1,2}(?:\.\d+)?)\s*[, ]\s*(-?\d{1,3}(?:\.\d+)?)\s*$'),
  ];
  for (final p in patterns) {
    final m = p.firstMatch(t);
    if (m != null) {
      final lat = double.parse(m.group(1)!), lng = double.parse(m.group(2)!);
      if (lat.abs() <= 90 && lng.abs() <= 180) return (lat: lat, lng: lng);
    }
  }
  return null;
}
