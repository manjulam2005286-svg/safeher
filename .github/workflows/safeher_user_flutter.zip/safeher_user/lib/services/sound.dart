import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';

/// Generates simple tones as WAV files (no audio assets needed) and plays them.
class Sound {
  Sound._();
  static final AudioPlayer _player = AudioPlayer();

  static Uint8List _wav(List<double> samples, int rate) {
    final data = ByteData(44 + samples.length * 2);
    void str(int o, String s) {
      for (var i = 0; i < s.length; i++) {
        data.setUint8(o + i, s.codeUnitAt(i));
      }
    }
    str(0, 'RIFF');
    data.setUint32(4, 36 + samples.length * 2, Endian.little);
    str(8, 'WAVE');
    str(12, 'fmt ');
    data.setUint32(16, 16, Endian.little);
    data.setUint16(20, 1, Endian.little);
    data.setUint16(22, 1, Endian.little);
    data.setUint32(24, rate, Endian.little);
    data.setUint32(28, rate * 2, Endian.little);
    data.setUint16(32, 2, Endian.little);
    data.setUint16(34, 16, Endian.little);
    str(36, 'data');
    data.setUint32(40, samples.length * 2, Endian.little);
    for (var i = 0; i < samples.length; i++) {
      data.setInt16(44 + i * 2, (samples[i].clamp(-1.0, 1.0) * 32767 * 0.6).round(), Endian.little);
    }
    return data.buffer.asUint8List();
  }

  /// Phone-style ring: 440 Hz + 480 Hz for 1 s, then 2 s silence.
  static Uint8List ringTone() {
    const rate = 16000;
    final s = List<double>.generate(rate * 3, (i) {
      if (i >= rate) return 0;
      final t = i / rate;
      return 0.5 * (math.sin(2 * math.pi * 440 * t) + math.sin(2 * math.pi * 480 * t));
    });
    return _wav(s, rate);
  }

  /// Short beep for the Safe Check prompt.
  static Uint8List beep() {
    const rate = 16000;
    return _wav(List<double>.generate(rate ~/ 3, (i) => math.sin(2 * math.pi * 880 * i / rate)), rate);
  }

  static Future<void> _play(String name, Uint8List bytes, {bool loop = false}) async {
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/$name.wav');
    if (!await f.exists()) await f.writeAsBytes(bytes);
    await _player.stop();
    await _player.setReleaseMode(loop ? ReleaseMode.loop : ReleaseMode.stop);
    await _player.play(DeviceFileSource(f.path));
  }

  static Future<void> ring() => _play('ring', ringTone(), loop: true);
  static Future<void> playBeep() => _play('beep', beep());
  static Future<void> stop() => _player.stop();
}
