import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import '../api.dart';
import 'location.dart';

/// Streams the user's live location to the server while an SOS alert is open.
/// Same rules as the web app: at most one update every 4 s, a heartbeat every ~15 s
/// when standing still, and a manually set exact location is never overwritten by a
/// rough fix (accuracy worse than 200 m).
class LiveLocation extends ChangeNotifier {
  LiveLocation._();
  static final LiveLocation I = LiveLocation._();

  int? alertId;
  bool manual = false;
  DateTime? lastSent;
  double? lastLat, lastLng, lastAccuracy;
  String? error;
  StreamSubscription<Position>? _sub;
  Timer? _beat;
  bool _sending = false;

  bool get active => alertId != null;

  Future<void> start(int id, {bool manualPin = false}) async {
    if (alertId == id) {
      // already running for this alert (or waiting for permission): just sync the manual flag
      if (manual != manualPin) {
        manual = manualPin;
        notifyListeners();
      }
      return;
    }
    await stop();
    alertId = id;
    manual = manualPin;
    error = null;
    try {
      await ensureLocationPermission();
    } on LocationError catch (e) {
      error = e.message;
      notifyListeners();
      return;
    }
    _sub = Geolocator.getPositionStream(locationSettings: trackingSettings()).listen(_send, onError: (Object e) {
      error = 'Waiting for a location signal…';
      notifyListeners();
    });
    _beat = Timer.periodic(const Duration(seconds: 15), (_) async {
      try {
        _send(await Geolocator.getCurrentPosition(
            locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 12))));
      } catch (_) {}
    });
    notifyListeners();
  }

  Future<void> _send(Position p) async {
    final id = alertId;
    if (id == null || _sending) return;
    if (manual && p.accuracy > 200) return; // keep the user's exact pin
    final now = DateTime.now();
    if (lastSent != null && lastLat != null) {
      final secs = now.difference(lastSent!).inMilliseconds / 1000;
      if (secs < 4) return;
      if (distanceM(lastLat!, lastLng!, p.latitude, p.longitude) < 5 && secs < 14) return;
    }
    _sending = true;
    try {
      await Api.I.updateLocation(id, p.latitude, p.longitude, accuracy: p.accuracy);
      lastSent = now;
      lastLat = p.latitude;
      lastLng = p.longitude;
      lastAccuracy = p.accuracy;
      manual = false;
      error = null;
    } on ApiException catch (e) {
      error = e.message;
      if (e.status == 409 || e.status == 404) await stop(); // alert closed
    } finally {
      _sending = false;
      notifyListeners();
    }
  }

  /// Called after the user sets her exact location manually.
  void markManual(double lat, double lng) {
    manual = true;
    lastLat = lat;
    lastLng = lng;
    lastSent = DateTime.now();
    lastAccuracy = null;
    notifyListeners();
  }

  Future<void> stop() async {
    await _sub?.cancel();
    _sub = null;
    _beat?.cancel();
    _beat = null;
    alertId = null;
    manual = false;
    lastSent = null;
    lastLat = lastLng = lastAccuracy = null;
    notifyListeners();
  }
}
