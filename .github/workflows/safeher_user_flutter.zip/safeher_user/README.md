# SafeHer – Women App (Flutter)

Mobile app for women. Connects to the existing SafeHer Node.js server (same API as the web app).

## Features
- Register / login (separate server address setting on the login screen)
- **Emergency SOS** – press & hold 3 seconds (prevents accidental alerts)
- **Live location** – sent every 4–15 s while the alert is open; keeps running when the app is minimised (Android foreground service with a "SafeHer SOS is active" notification)
- **Exact location picker** – if the location is approximate, search a place, paste a Google Maps link / coordinates, or tap the map
- Emergency page: timeline, live map, contacts (call buttons), Mark Safe, Cancel Emergency
- Emergency contacts: add, edit, delete, set primary
- Safe Check Timer (10/20/30/60 min + 6 s demo) with "Are you safe?" prompt
- Fake incoming call, Share My Location (copy, Google Maps, WhatsApp)
- Safety Center: emergency status, setup checklist, daily tips, preparation, Call 112
- Alert history with status filter

## Requirements
- Flutter 3.22 or newer (`flutter --version`)
- Android phone (USB debugging on) or emulator
- The SafeHer server running on a laptop on the **same Wi-Fi** as the phone

## Setup (one time)
```
cd safeher_user
setup.bat          (Windows)
./setup.sh         (Linux / macOS)
```
This runs `flutter create` (adds the android/ios folders), copies SafeHer's AndroidManifest
(location + background service permissions), and runs `flutter pub get`.

## Run
1. On the laptop: `npm start` in the SafeHer server folder.
2. Find the laptop's Wi-Fi IP: `ipconfig` (Windows) or `ip addr` / `hostname -I` (Linux).
3. `flutter run`
4. In the app: Login screen → **Server settings** → `http://<laptop-ip>:5050` → Save.
5. Log in or create an account. Allow location when asked.

If the phone can't connect: allow port 5050 in the laptop firewall (`sudo ufw allow 5050` on Ubuntu).

## Build an installable APK
```
flutter build apk --release
```
APK: `build/app/outputs/flutter-apk/app-release.apk`

## Notes
- Contact notifications are a demo (no SMS service connected), same as the web app.
- iOS: background location is off by default. To enable it, add `UIBackgroundModes → location`
  in `ios/Runner/Info.plist` and set `allowBackgroundLocationUpdates: true` in `lib/services/location.dart`.
- If `flutter pub get` reports a version conflict on a newer Flutter, run `flutter pub upgrade --major-versions`.
