@echo off
REM One-time setup: generates the Android/iOS platform folders, then applies SafeHer's permissions.
cd /d "%~dp0"
call flutter create --org com.safeher --project-name safeher_user --platforms android,ios .
copy /Y setup\AndroidManifest.xml android\app\src\main\AndroidManifest.xml
if exist test\widget_test.dart del test\widget_test.dart
call flutter pub get
echo.
echo Done. Connect your phone (USB debugging on) and run:  flutter run
pause
