#!/usr/bin/env bash
# One-time setup: generates the Android/iOS platform folders, then applies SafeHer's permissions.
set -e
cd "$(dirname "$0")"
flutter create --org com.safeher --project-name safeher_user --platforms android,ios .
cp setup/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
rm -f test/widget_test.dart
PL=ios/Runner/Info.plist
if [ -f "$PL" ] && [ -x /usr/libexec/PlistBuddy ]; then
  echo "Adding iOS settings to Info.plist"
  /usr/libexec/PlistBuddy -c "Add :NSLocationWhenInUseUsageDescription string 'SafeHer uses your location to send it with your SOS alert.'" "$PL" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Add :NSLocationAlwaysAndWhenInUseUsageDescription string 'SafeHer shares your live location while an SOS alert is active.'" "$PL" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Add :NSAppTransportSecurity dict" "$PL" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Add :NSAppTransportSecurity:NSAllowsArbitraryLoads bool true" "$PL" 2>/dev/null || true
fi
flutter pub get
echo ""
echo "Done. Connect your phone (USB debugging on) and run:  flutter run"
